from __future__ import annotations

import uuid
from enum import Enum

from sqlalchemy import Enum as SAEnum, ForeignKey, String, Text
from sqlalchemy.dialects.postgresql import UUID as PGUUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from backend.database import Base


class AgentTaskStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    CREATED = "created"
    CI_RUNNING = "ci_running"
    MERGED = "merged"
    DONE = "done"
    FAILED = "failed"


class AgentTask(Base):
    __tablename__ = "agent_tasks"

    id: Mapped[uuid.UUID] = mapped_column(
        PGUUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    user_id: Mapped[uuid.UUID] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    repo_name: Mapped[str] = mapped_column(String, nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    status: Mapped[AgentTaskStatus] = mapped_column(
        SAEnum(AgentTaskStatus, name="agent_task_status"),
        default=AgentTaskStatus.PENDING,
        nullable=False,
    )
    pr_url: Mapped[str | None] = mapped_column(String, nullable=True)

    user: Mapped["User"] = relationship(back_populates="agent_tasks")
