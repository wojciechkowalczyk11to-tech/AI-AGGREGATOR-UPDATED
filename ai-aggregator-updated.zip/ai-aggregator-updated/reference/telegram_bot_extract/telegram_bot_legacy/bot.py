#!/usr/bin/env python3
"""
Telegram Bot - AI Aggregator
Webhook/Polling mode for 24/7 production operation.
Supports model selection via commands and seamless message forwarding to FastAPI backend.
"""
import os
import logging
import httpx
import asyncio
from typing import Optional, Dict, Any
from dotenv import load_dotenv
from telegram import Update
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    filters,
    ContextTypes
)
from telegram.constants import ChatAction

# Load environment variables
load_dotenv()

# Config from Environment
BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
BACKEND_URL = os.getenv("BACKEND_URL", "http://backend_api:8000")
WEBHOOK_URL = os.getenv("TELEGRAM_WEBHOOK_URL")

# Logging Setup
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# In-memory mapping for session optimization
# telegram_chat_id -> backend_user_id
user_cache: Dict[int, str] = {}

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Registers the user with the backend and displays the main menu."""
    if not update.effective_chat:
        return
        
    chat_id = update.effective_chat.id
    
    try:
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{BACKEND_URL}/users/register",
                json={"telegram_chat_id": chat_id},
                timeout=10.0
            )
            resp.raise_for_status()
            data = resp.json()
            user_cache[chat_id] = data["user_id"]
            
            welcome_text = (
                "🤖 *AI Aggregator Bot Activated*\n\n"
                "I can access multiple AI models. Use a command followed by your prompt or just type naturally.\n\n"
                "*Available Models:*\n"
                "/claude - Claude 3.5 Sonnet\n"
                "/gpt - GPT-4 Turbo\n"
                "/deepseek - DeepSeek Reasoner\n"
                "/jules - Jules Agent (Gemini)\n"
                "/groq - Groq (Ultra Fast)\n"
                "/mistral - Mistral Large\n\n"
                "Current Default: *Gemini 1.5 Flash*"
            )
            await update.message.reply_text(welcome_text, parse_mode="Markdown")
            
    except Exception as e:
        logger.error(f"User registration failed for {chat_id}: {str(e)}")
        await update.message.reply_text("❌ Initialization failed. Please ensure the backend is online.")

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Processes incoming messages, identifies model commands, and communicates with backend."""
    if not update.message or not update.message.text or not update.effective_chat:
        return

    chat_id = update.effective_chat.id
    raw_text = update.message.text
    
    # Check if user is registered/cached
    user_id = user_cache.get(chat_id)
    if not user_id:
        # Attempt to register on-the-fly if cache is empty
        try:
            async with httpx.AsyncClient() as client:
                resp = await client.post(f"{BACKEND_URL}/users/register", json={"telegram_chat_id": chat_id})
                if resp.status_code == 200:
                    user_id = resp.json()["user_id"]
                    user_cache[chat_id] = user_id
                else:
                    await update.message.reply_text("Please run /start first.")
                    return
        except Exception:
            await update.message.reply_text("Backend connection error. Try /start.")
            return

    # Determine model and clean text
    requested_model: Optional[str] = None
    prompt_text = raw_text

    if raw_text.startswith("/"):
        parts = raw_text.split(maxsplit=1)
        command = parts[0][1:].lower()
        valid_models = ["claude", "gpt", "deepseek", "groq", "mistral", "jules", "gemini"]
        
        if command in valid_models:
            requested_model = command
            if len(parts) > 1:
                prompt_text = parts[1]
            else:
                await update.message.reply_text(f"Usage: /{command} [your question]")
                return

    try:
        # Visual feedback: 'typing...'
        await context.bot.send_chat_action(chat_id=chat_id, action=ChatAction.TYPING)
        
        # Backend Request
        payload = {
            "user_id": user_id,
            "message": prompt_text,
            "model": requested_model
        }
        
        async with httpx.AsyncClient() as client:
            # Longer timeout for DeepSeek/Claude reasoning
            response = await client.post(
                f"{BACKEND_URL}/chat/",
                json=payload,
                timeout=120.0 
            )
            response.raise_for_status()
            data = response.json()
            
            # Metadata construction
            model_name = data.get("model_used", "Unknown")
            tokens = data.get("tokens_used", 0)
            cost = data.get("cost_usd", 0.0)
            
            meta_footer = f"\n\n───\n🤖 `{model_name}` | 💳 `${cost:.4f}` | ⚡ `{tokens}` tokens"
            
            if data.get("fallback_used"):
                meta_footer += " | ⚠️ Fallback"
            
            await update.message.reply_text(
                f"{data['response']}{meta_footer}",
                parse_mode="Markdown"
            )
            
    except httpx.HTTPStatusError as e:
        logger.error(f"Backend API error: {e.response.status_code} - {e.response.text}")
        await update.message.reply_text("⚠️ The AI backend returned an error.")
    except Exception as e:
        logger.error(f"Critical error in handle_message: {str(e)}")
        await update.message.reply_text("🚨 An internal error occurred while processing your request.")

def main() -> None:
    """Initializes and runs the bot application."""
    if not BOT_TOKEN:
        logger.critical("TELEGRAM_BOT_TOKEN environment variable is missing.")
        return

    application = Application.builder().token(BOT_TOKEN).build()

    # Handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    
    # Register model commands to the same handler
    model_filters = filters.Regex(r"^/(claude|gpt|deepseek|groq|mistral|jules|gemini)")
    application.add_handler(MessageHandler(model_filters, handle_message))

    if WEBHOOK_URL:
        # Production: Webhook
        logger.info(f"Running in Webhook mode: {WEBHOOK_URL}")
        application.run_webhook(
            listen="0.0.0.0",
            port=8001,
            url_path=BOT_TOKEN,
            webhook_url=f"{WEBHOOK_URL}/{BOT_TOKEN}",
            secret_token=os.getenv("WEBHOOK_SECRET") # Recommended for security
        )
    else:
        # Development: Polling
        logger.info("Running in Polling mode (Development)")
        application.run_polling()

if __name__ == "__main__":
    main()
