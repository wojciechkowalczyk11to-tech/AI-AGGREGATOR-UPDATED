import pytest
from unittest.mock import MagicMock, patch, AsyncMock
from httpx import AsyncClient
from backend.providers.types import ProviderResponse

@pytest.fixture
def mock_provider_factory():
    with patch("backend.api.chat_routes.ProviderFactory") as mock:
        # Setup default mock provider
        mock_instance = MagicMock()
        mock_instance.generate = AsyncMock(return_value=ProviderResponse(
            content="Mock Response",
            model_name="mock-model",
            input_tokens=10,
            output_tokens=10,
            cost_usd=0.001,
            provider="mock-provider"
        ))
        mock.create.return_value = mock_instance
        mock.get_available_providers.return_value = ["mock-provider", "claude"]
        yield mock

@pytest.mark.asyncio
async def test_chat_unknown_provider(async_client: AsyncClient, mock_provider_factory):
    # Setup user
    reg = await async_client.post("/api/users/register", json={"telegram_chat_id": 12345})
    token = reg.json()["access_token"]
    user_id = reg.json()["id"]
    headers = {"Authorization": f"Bearer {token}"}

    # Simulate ProviderFactory raising ValueError for "unknown"
    def create_side_effect(name):
        if name == "unknown":
            raise ValueError("Unknown provider")
        return MagicMock() # Return default mock otherwise

    mock_provider_factory.create.side_effect = create_side_effect

    # Send request with unknown provider command
    resp = await async_client.post("/api/chat/", json={
        "user_id": user_id,
        "prompt": "/unknown hello"
    }, headers=headers)

    assert resp.status_code == 400
    assert "Unknown provider" in resp.json()["detail"]

@pytest.mark.asyncio
async def test_chat_persistence_and_response(async_client: AsyncClient, mock_provider_factory):
    # Setup user
    reg = await async_client.post("/api/users/register", json={"telegram_chat_id": 67890})
    token = reg.json()["access_token"]
    user_id = reg.json()["id"]
    headers = {"Authorization": f"Bearer {token}"}

    # Configure mock for "claude"
    mock_claude = MagicMock()
    mock_claude.generate = AsyncMock(return_value=ProviderResponse(
        content="Response from Claude",
        model_name="claude-3-sonnet",
        input_tokens=10,
        output_tokens=10,
        cost_usd=0.01,
        provider="claude"
    ))

    def create_side_effect(name):
        if name == "claude":
            return mock_claude
        # Return generic mock for others
        mock_generic = MagicMock()
        mock_generic.generate = AsyncMock(return_value=ProviderResponse(
            content="Generic",
            model_name="generic",
            input_tokens=1,
            output_tokens=1,
            cost_usd=0,
            provider="generic"
        ))
        return mock_generic

    mock_provider_factory.create.side_effect = create_side_effect

    # 1. Send /claude command
    resp = await async_client.post("/api/chat/", json={
        "user_id": user_id,
        "prompt": "/claude Hello"
    }, headers=headers)

    assert resp.status_code == 200
    data = resp.json()
    assert data["provider"] == "claude"
    assert data["model_name"] == "claude-3-sonnet"

    # 2. Verify persistence: Next message without command should use claude
    # We reset the mock call history to check if claude is created
    mock_provider_factory.create.reset_mock()
    mock_provider_factory.create.side_effect = create_side_effect # restore side effect

    await async_client.post("/api/chat/", json={
        "user_id": user_id,
        "prompt": "Follow up"
    }, headers=headers)

    # The router should have picked "claude" as primary, so fallback executes "claude" first.
    # Verify create was called with "claude"
    mock_provider_factory.create.assert_any_call("claude")
