# 🤖 GPT CODEX — AI AGGREGATOR TELEGRAM BOT v2.0

> **IMPORTANT CONTEXT:** This repository is EMPTY. Create everything from scratch.
> The attached ZIP (telegram_bot_extract.zip) is REFERENCE ONLY —
> do NOT copy files from it directly. Use it to understand existing
> patterns, API contracts, and UX conventions.

## MISSION

Build a complete, production-ready Telegram bot repository `ai-aggregator-updated/` from scratch.
The bot is a **thin client** for an existing FastAPI backend. It handles user interaction, command routing, provider selection, meta-footers, file handling, and all Telegram-specific UX.

**Repository name:** `ai-aggregator-updated`
**Create a fresh repo** — do NOT modify existing files in the ZIP. Use them as reference only.

---

## ABSOLUTE RULES

1. **ZERO TODO / ZERO PLACEHOLDER** — every file complete, production-ready
2. **ZERO `pass` without logic**, ZERO `...`, ZERO `# implement later`
3. **Full typing** — `from __future__ import annotations`, strict types everywhere
4. **Error handling** — try/except, retry on 401, graceful degradation
5. **Docstrings** — every class and public function
6. **Security** — env vars only, input validation, no hardcoded secrets
7. **Tests** — each phase has verification tests. Run them before moving to the next phase.

---

## REFERENCE CODE (in telegram_bot_extract.zip)

The ZIP contains the existing codebase. **READ EVERY FILE** before writing code.

```
telegram_bot_current/       ← BASE BOT (good auth pattern, error hierarchy, config validation)
telegram_bot_legacy/        ← LEGACY BOT (good UX: meta-footers with model/cost/tokens)
backend_api_routes/         ← FastAPI endpoints (chat, rag, agent, analytics, admin, user, metrics)
backend_providers/          ← Provider interface (base.py, types.py, factory.py — 7 providers)
backend_auth/               ← JWT auth (jwt.py)
backend_models/             ← SQLAlchemy models (User, Conversation, Document, UsageLog, AgentTask)
backend_core/               ← Rate limits (tier-based: basic/premium/premium_plus)
backend_config_settings.py  ← Backend settings
Dockerfile.telegram         ← Docker config
tests/                      ← Existing tests (handlers, API flow, auth)
```

### KEY PATTERNS TO REUSE:
- **From `telegram_bot_current/handlers.py`**: Auth retry pattern `_get_or_register_user`, command-only regex detection, typing indicator
- **From `telegram_bot_current/services.py`**: Error class hierarchy (`BackendServiceError` → `AuthenticationError` / `ClientError`), httpx AsyncClient pattern
- **From `telegram_bot_current/config.py`**: Settings validation with `validate()`, token format regex, `allowed_telegram_user_ids` property
- **From `telegram_bot_legacy/bot.py`**: Meta-footer format (`🤖 model | 💳 $cost | ⚡ tokens`), in-memory user_cache, model command with inline prompt
- **From `backend_api_routes/`**: All request/response schemas — use these as the API contract

---

## TARGET REPOSITORY STRUCTURE

```
ai-aggregator-updated/
├── bot.py                              # Main entry point
├── config.py                           # Pydantic BaseSettings
├── requirements.txt
├── Dockerfile
├── docker-compose.yml                  # Bot + Redis
├── .env.example
├── pytest.ini
│
├── handlers/
│   ├── __init__.py                     # register_all_handlers(app)
│   ├── start.py                        # /start
│   ├── help.py                         # /help
│   ├── chat.py                         # Text messages → AI
│   ├── commands.py                     # /claude, /gpt, /gemini, /deepseek, /groq, /mistral, /grok, /openrouter
│   ├── voice.py                        # Voice → STT → AI → text
│   ├── documents.py                    # PDF/DOCX/TXT/ZIP upload → RAG or workspace
│   ├── images.py                       # /imagine <prompt>
│   ├── rag.py                          # /rag <query>, /upload
│   ├── usage.py                        # /usage
│   ├── plan.py                         # /plan — tier info + upgrade
│   ├── admin.py                        # /admin stats, /admin users
│   ├── settings_cmd.py                 # /settings — inline keyboard
│   ├── inline.py                       # Inline mode @bot query
│   ├── callbacks.py                    # CallbackQuery dispatcher
│   ├── notebook.py                     # /notebook — Groq casual mode
│   ├── workspace.py                    # /workspace, /download
│   ├── memory.py                       # /memory, /forget
│   ├── repurpose.py                    # /repurpose <text>
│   └── errors.py                       # Global error handler
│
├── services/
│   ├── __init__.py
│   ├── base.py                         # BaseService with auth, retry, error handling
│   ├── auth_service.py                 # Register, token cache
│   ├── chat_service.py                 # Send message, fallback chain, streaming
│   ├── rag_service.py                  # Upload, search, list documents
│   ├── image_service.py                # Generate image
│   ├── analytics_service.py            # Usage stats
│   ├── agent_service.py                # Tasks, GitHub
│   ├── admin_service.py                # Admin endpoints
│   ├── provider_policy_service.py      # Per-user permissions + USD quota
│   └── provider_normalization.py       # Alias → canonical provider
│
├── keyboards/
│   ├── __init__.py
│   ├── main_menu.py
│   ├── model_selector.py
│   ├── settings_keyboard.py
│   ├── plan_keyboard.py
│   └── pagination.py
│
├── middleware/
│   ├── __init__.py
│   ├── auth.py                         # ensure_authenticated + with_auth_retry
│   ├── rate_limit.py                   # Local backup rate limiting
│   ├── logging_mw.py                   # Structured JSON logging
│   └── typing_indicator.py             # Auto typing action
│
├── utils/
│   ├── __init__.py
│   ├── formatters.py                   # MarkdownV2 escape, code blocks
│   ├── meta_footer.py                  # 🤖 model | 💳 $cost | ⚡ tokens | ⏱ time
│   ├── message_splitter.py             # Split at 4096 chars, respect code blocks
│   ├── file_processor.py               # PDF/DOCX/TXT text extraction
│   └── voice_processor.py              # OGG → WAV conversion
│
└── tests/
    ├── conftest.py
    ├── test_config.py
    ├── test_services.py
    ├── test_handlers.py
    ├── test_formatters.py
    ├── test_meta_footer.py
    ├── test_message_splitter.py
    ├── test_provider_policy.py
    ├── test_provider_normalization.py
    └── test_middleware_auth.py
```

---

## BACKEND API SPECIFICATION (COMPLETE CONTRACT)

### Base URL: `{BACKEND_URL}` (env, default `http://localhost:8000`)

### Authentication
- **Register:** `POST /api/users/register`
  - Body: `{"telegram_chat_id": int, "settings": {}}`
  - Response: `{"id": "uuid", "telegram_chat_id": int, "settings": {}, "created_at": "iso", "access_token": "jwt_token", "token_type": "bearer"}`
  - Note: Idempotent — returns existing user if already registered, always returns fresh JWT
- **Auth Header:** `Authorization: Bearer {access_token}`
- JWT expires in 30 minutes. Bot caches in `context.user_data`. On 401 → re-register to get fresh token.

### Chat
- **Send message:** `POST /api/chat/` — Auth required
  - Body: `{"user_id": "uuid", "prompt": "text", "conversation_id": "uuid|null", "use_rag": false, "stream": false, "max_tokens": null, "temperature": null}`
  - Response: `{"conversation_id": "uuid", "response": "text", "model_name": "gemini-3-flash", "provider": "gemini", "input_tokens": 150, "output_tokens": 340, "cost_usd": 0.0012, "rag_status": null, "rag_message": null}`
  - The backend handles provider routing, fallback, and model selection based on `user.settings.preferred_model`
  - If prompt starts with `/provider_name text` — backend parses the command, validates provider, persists preference, and routes to that provider
- **Get providers:** `GET /api/chat/providers` — No auth
  - Response: `["gemini", "claude", "openai", "deepseek", "groq", "mistral", "openrouter"]`

### User Settings
- **Update settings:** `PUT /api/users/{user_id}/settings` — Auth required
  - Body: `{"settings": {"preferred_model": "claude"}}`
  - Response: `{"id": "uuid", "telegram_chat_id": int, "settings": {...}, "created_at": "iso"}`

### RAG (Knowledge Base)
- **Upload:** `POST /api/rag/upload` — Auth, multipart/form-data
  - Files: `file` (PDF/DOCX/TXT, max 10MB)
  - Response: `{"id": "uuid", "filename": "doc.pdf", "chromadb_collection_name": "...", "created_at": "iso"}`
- **Search:** `POST /api/rag/search` — Auth
  - Body: `{"query": "text", "top_k": 5}`
  - Response: `{"results": [{"content": "...", "score": 0.87, "metadata": {...}}]}`

### Analytics
- **Usage stats:** `GET /api/analytics/usage?days=30` — Auth
  - Response: `{"period_days": 30, "data": [{"date": "2026-02-01", "provider": "gemini", "tokens": 5000, "cost_usd": 0.05, "request_count": 12}], "totals": {"tokens": 45000, "cost_usd": 0.45}}`
- **Compare providers:** `GET /api/analytics/usage/compare?input_tokens=1000&output_tokens=500` — No auth
  - Response: `{"input_tokens": 1000, "output_tokens": 500, "providers": [{"provider": "gemini", "model": "gemini-flash", "cost_usd": 0.001}]}`

### Agent
- **Create task:** `POST /api/agent/task` — Auth
  - Body: `{"repo_name": "owner/repo", "description": "task text", "model": "gemini"}`
  - Response: `{"task_id": "uuid"}`
- **Task status:** `GET /api/agent/tasks/{task_id}` — Auth
  - Response: `{"id": "uuid", "repo_name": "...", "description": "...", "status": "running|done|failed", "pr_url": "https://...", "ci_checks": [...]}`
- **GitHub connect:** `POST /api/agent/connect-github` — Auth
  - Body: `{"code": "oauth_code"}`
- **List repos:** `GET /api/agent/repositories` — Auth

### Admin (superuser only)
- **System overview:** `GET /api/admin/stats/overview` — Superuser auth
  - Response: `{"total_users": 50, "active_users_24h": 12, "total_requests_24h": 340, "total_cost_24h": 1.23, "total_cost_all_time": 45.67, "avg_cost_per_request": 0.003, "most_popular_provider": "gemini", "tier_distribution": {"basic": 42, "premium": 8}}`
- **List users:** `GET /api/admin/users?limit=100&offset=0` — Superuser auth
  - Response: list of `{"user_id": "uuid", "telegram_id": int, "subscription_tier": "basic", "total_requests": 100, "total_cost_usd": 1.23, "last_activity": "iso"}`
- **Cost breakdown:** `GET /api/admin/costs/breakdown?days=7` — Superuser auth
- **Upgrade user:** `POST /api/admin/users/{user_id}/upgrade` — Body: `{"new_tier": "premium"}`

### Image Generation
- **Generate:** `POST /api/image/generate` — Auth
  - Body: `{"prompt": "description", "negative_prompt": ""}`
  - Response: `{"image_base64": "...", "generation_id": "uuid", "safety_passed": true}`

### Rate Limit Tiers
```
basic:          10K tokens/day,  50 req/hour,  50 RAG/day
premium:       100K tokens/day, 500 req/hour, 500 RAG/day
premium_plus:  500K tokens/day, 2K req/hour, 2K RAG/day
```

---

## AI PROVIDERS (8 providers)

| Command | Provider | Canonical ID | Model | Cost/1M tokens |
|---------|----------|--------------|-------|----------------|
| /gemini | Google | `gemini` | Gemini 3 Flash | ~$0.10 |
| /claude | Anthropic | `claude` | Claude 3.5 Sonnet | ~$3.00 |
| /gpt | OpenAI | `openai` | GPT-4o | ~$2.50 |
| /deepseek | DeepSeek | `deepseek` | DeepSeek-V3 | ~$0.14 |
| /groq | Groq | `groq` | Llama 3.3 70B | ~$0.06 |
| /mistral | Mistral | `mistral` | Mistral Large | ~$2.00 |
| /openrouter | OpenRouter | `openrouter` | Auto-route | varies |
| /grok | xAI | `grok` | Grok-2 | ~$2.00 |

Default: `gemini` (cheapest + Vertex AI integration).

**Default fallback chain:** `gemini → deepseek → groq → mistral → openrouter → grok → claude → openai`

---

## PROVIDER POLICY SYSTEM (CRITICAL)

Per-user provider permissions + USD-based quota. Loaded from env `PROVIDER_POLICY_JSON`:

```json
{
  "default": {
    "providers": {
      "gemini": {"enabled": true},
      "deepseek": {"enabled": true},
      "groq": {"enabled": true, "daily_usd_cap": 1.0},
      "mistral": {"enabled": true, "daily_usd_cap": 2.0},
      "openrouter": {"enabled": true, "daily_usd_cap": 1.0},
      "grok": {"enabled": true, "daily_usd_cap": 2.0},
      "claude": {"enabled": true, "daily_usd_cap": 5.0},
      "openai": {"enabled": true, "daily_usd_cap": 5.0}
    }
  },
  "users": {
    "8554224381": {
      "providers": {
        "openai": {"enabled": false},
        "claude": {"enabled": false}
      }
    }
  }
}
```

### `services/provider_normalization.py`
```python
from __future__ import annotations
import logging

logger = logging.getLogger(__name__)

_ALIASES: dict[str, str] = {
    "gpt": "openai", "gpt-4": "openai", "gpt-4o": "openai", "openai": "openai",
    "claude": "claude", "claude-sonnet": "claude", "anthropic": "claude",
    "gemini": "gemini", "gemini-flash": "gemini", "google": "gemini",
    "deepseek": "deepseek", "deepseek-chat": "deepseek", "deepseek-v3": "deepseek",
    "groq": "groq", "groq-llama": "groq", "llama": "groq",
    "grok": "grok", "xai": "grok",
    "mistral": "mistral", "mistral-large": "mistral",
    "openrouter": "openrouter",
}

def canonical_provider(name: str) -> str:
    """Return canonical provider id. Unknown names returned lowercased."""
    raw = (name or "").strip().lower()
    if not raw:
        return raw
    return _ALIASES.get(raw, raw)
```

### `services/provider_policy_service.py`
Full implementation with:
- `ProviderRule(BaseModel)`: enabled, daily_usd_cap, monthly_usd_cap
- `ProviderPolicy(BaseModel)`: providers dict
- `ProviderPolicyConfig(BaseModel)`: default + users overrides
- `ProviderPolicyService`:
  - `from_env()` — load from PROVIDER_POLICY_JSON
  - `get_effective_policy(telegram_id)` — merge default + user overrides
  - `is_provider_enabled(telegram_id, provider)` → bool
  - `is_within_budget(telegram_id, provider, snapshot)` → bool
  - `filter_provider_chain(telegram_id, chain)` → filtered list

Copy the full implementation from the reference gpt.md file (lines 1501-1716).

---

## UX REQUIREMENTS

### Meta-footer (REQUIRED on EVERY AI response)
```
{response_text}

───
🤖 `{model_name}` | 💳 `${cost:.4f}` | ⚡ `{tokens}` tok | ⏱ `{elapsed:.1f}s`
```
If fallback was used: append `| ⚠️ Fallback`

### Message Splitting
- Telegram limit: 4096 chars per message
- If response > 4000 chars → split into multiple messages
- NEVER split inside a code block or mid-sentence
- If response has code blocks > 4000 chars total → send as `.md` or `.txt` document

### Markdown Formatting
- Use `parse_mode="MarkdownV2"` for all AI responses
- Escape special chars: `_*[]()~>#+\-=|{}.!`
- Code blocks: ` ```language\ncode``` `
- Fallback: if MarkdownV2 parsing fails → retry with `parse_mode=None` (plain text)

### Typing Indicator
- Send `ChatAction.TYPING` immediately when message received
- Repeat every 4 seconds while waiting for backend response

### Error Messages (Polish UX)
- Backend down: `⚠️ Serwer AI jest chwilowo niedostępny. Spróbuj za chwilę.`
- Rate limit: `🚫 Osiągnąłeś limit zapytań. Sprawdź swój plan: /plan`
- Auth error: auto-refresh → if fail: `Sesja wygasła. Wpisz /start`
- Unknown provider: `❌ Nieznany model. Dostępne modele: /help`
- Daily cap: `💰 Dzienny limit budżetu wyczerpany. Spróbuj jutro lub zmień model.`
- All providers failed: `🔴 Wszystkie modele AI są niedostępne. Spróbuj za kilka minut.`

---

## TEST USER IDS

```python
ADMIN_USER_IDS = [8236214480, 8164622121, 577356488]
RESTRICTED_USERS = {
    8554224381: "no claude/openai"
}
```

---

## COMPLETE COMMAND LIST

```
/start          — Register + welcome + command list
/help           — Dynamic provider list + all commands
/settings       — Inline keyboard: default model, language
/usage          — Usage stats: tokens, cost, by provider (30 days)
/plan           — Current tier + pricing + upgrade link
/memory         — Memory stats (messages count, tokens)
/forget         — Clear conversation history
/new            — Start new conversation

# AI Models (switch + optional inline prompt)
/claude [text]  — Claude 3.5 Sonnet
/gpt [text]     — GPT-4o
/gemini [text]  — Gemini 3 Flash
/deepseek [text]— DeepSeek-V3
/groq [text]    — Groq Llama 3.3
/mistral [text] — Mistral Large
/grok [text]    — Grok-2
/openrouter [text] — OpenRouter auto

# Features
/imagine <prompt>   — Image generation
/rag <query>        — Search knowledge base
/upload             — Upload document (reply to file with this command)
/notebook           — Switch to Notebook LM (cheap Groq casual mode)
/workspace          — List workspace files
/download           — Export workspace as ZIP
/repurpose <text>   — Generate social media posts
/export             — Export conversation as TXT

# Admin (superuser only)
/admin stats        — System stats
/admin users        — User list
/admin costs        — Cost breakdown
```

---

# IMPLEMENTATION PHASES

## PHASE 1: Core Infrastructure

**Files to create:**
- `config.py`
- `bot.py`
- `services/__init__.py`
- `services/base.py`
- `services/auth_service.py`
- `services/provider_normalization.py`
- `middleware/__init__.py`
- `middleware/auth.py`
- `middleware/logging_mw.py`
- `utils/__init__.py`
- `utils/formatters.py`
- `utils/meta_footer.py`
- `utils/message_splitter.py`
- `requirements.txt`
- `.env.example`
- `pytest.ini`
- `tests/conftest.py`
- `tests/test_config.py`
- `tests/test_provider_normalization.py`

### `config.py` — Pydantic BaseSettings
```python
from __future__ import annotations
from pydantic_settings import BaseSettings, SettingsConfigDict

class BotSettings(BaseSettings):
    # Telegram
    telegram_bot_token: str
    telegram_mode: str = "polling"  # "polling" or "webhook"
    webhook_url: str = ""
    webhook_port: int = 8443
    webhook_path: str = "webhook"
    webhook_secret_token: str = ""

    # Backend
    backend_url: str = "http://localhost:8000"

    # Access control
    allowed_user_ids: list[int] = []     # Empty = deny all for safety
    admin_user_ids: list[int] = []       # Superuser Telegram IDs

    # Features
    voice_enabled: bool = True
    inline_enabled: bool = True
    image_gen_enabled: bool = True
    notebook_mode_enabled: bool = True

    # Provider Policy
    provider_policy_json: str = '{"default":{"providers":{"gemini":{"enabled":true},"deepseek":{"enabled":true},"groq":{"enabled":true,"daily_usd_cap":1.0}}}}'

    # Logging
    log_level: str = "INFO"
    log_json: bool = True

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")

    @property
    def is_webhook_mode(self) -> bool:
        return self.telegram_mode.lower() == "webhook"

settings = BotSettings()
```

### `services/base.py` — BaseService
```python
from __future__ import annotations
import httpx
import logging

logger = logging.getLogger(__name__)

class BackendServiceError(Exception):
    """Base error for backend communication."""

class AuthenticationError(BackendServiceError):
    """401 from backend."""

class RateLimitError(BackendServiceError):
    """429 from backend."""
    def __init__(self, message: str = "Rate limited", retry_after: int | None = None):
        super().__init__(message)
        self.retry_after = retry_after

class ClientError(BackendServiceError):
    """4xx (except 401, 429) from backend."""

class BackendTimeoutError(BackendServiceError):
    """Timeout connecting to backend."""

class BackendUnavailableError(BackendServiceError):
    """Cannot connect to backend."""

class AllProvidersFailedError(BackendServiceError):
    """All providers in fallback chain failed."""

class BaseService:
    def __init__(self, base_url: str, timeout: float = 60.0) -> None:
        self._client = httpx.AsyncClient(base_url=base_url, timeout=timeout)

    async def _request(self, method: str, path: str, token: str | None = None, **kwargs) -> dict | list:
        headers = kwargs.pop("headers", {})
        if token:
            headers["Authorization"] = f"Bearer {token}"
        try:
            resp = await self._client.request(method, path, headers=headers, **kwargs)
            if resp.status_code == 401:
                raise AuthenticationError("Token expired or invalid")
            if resp.status_code == 429:
                detail = "Rate limited"
                try:
                    detail = resp.json().get("detail", detail)
                except Exception:
                    pass
                raise RateLimitError(detail)
            if resp.status_code == 402:
                detail = "Daily cap reached"
                try:
                    detail = resp.json().get("detail", {}).get("message", detail)
                except Exception:
                    pass
                raise RateLimitError(detail)
            if 400 <= resp.status_code < 500:
                detail = "Client error"
                try:
                    detail = resp.json().get("detail", detail)
                except Exception:
                    detail = resp.text[:200]
                raise ClientError(str(detail))
            resp.raise_for_status()
            return resp.json()
        except httpx.TimeoutException as exc:
            raise BackendTimeoutError("Backend request timed out") from exc
        except httpx.RequestError as exc:
            raise BackendUnavailableError(f"Cannot reach backend: {exc}") from exc

    async def close(self) -> None:
        await self._client.aclose()
```

### `middleware/auth.py`
```python
from __future__ import annotations
import logging
from telegram import Update
from telegram.ext import ContextTypes
from services.auth_service import AuthService
from services.base import AuthenticationError, BackendServiceError

logger = logging.getLogger(__name__)

async def ensure_authenticated(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
    auth_service: AuthService,
    force_refresh: bool = False,
) -> tuple[str, str]:
    """Return (user_id, access_token). Auto-registers if needed."""
    user_id = context.user_data.get("backend_user_id")
    token = context.user_data.get("access_token")

    if user_id and token and not force_refresh:
        return user_id, token

    if not update.effective_user:
        raise BackendServiceError("No effective user in update")

    result = await auth_service.register(update.effective_user.id)
    user_id = str(result["id"])
    token = result["access_token"]
    context.user_data["backend_user_id"] = user_id
    context.user_data["access_token"] = token
    context.user_data["subscription_tier"] = result.get("subscription_tier", "basic")
    return user_id, token


async def with_auth_retry(
    coro_factory,
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
    auth_service: AuthService,
):
    """Execute coro_factory(user_id, token). Retry once on 401."""
    user_id, token = await ensure_authenticated(update, context, auth_service)
    try:
        return await coro_factory(user_id, token)
    except AuthenticationError:
        logger.info("Auth failed, refreshing token for user %s", update.effective_user.id if update.effective_user else "?")
        user_id, token = await ensure_authenticated(update, context, auth_service, force_refresh=True)
        return await coro_factory(user_id, token)
```

### `utils/formatters.py`
```python
from __future__ import annotations
import re

# Characters that need escaping in MarkdownV2
_SPECIAL_CHARS = r'_*[]()~`>#+=|{}.!-'
_ESCAPE_RE = re.compile(f'([{re.escape(_SPECIAL_CHARS)}])')

def escape_markdown_v2(text: str) -> str:
    """Escape special characters for Telegram MarkdownV2."""
    return _ESCAPE_RE.sub(r'\\\1', text)

def format_code_block(code: str, language: str = "") -> str:
    """Wrap code in a MarkdownV2 code block."""
    return f"```{language}\n{code}\n```"

def safe_markdown_v2(text: str) -> str:
    """Escape text but preserve existing code blocks and inline code."""
    parts = []
    i = 0
    # Split on code blocks first (``` ... ```)
    code_block_re = re.compile(r'(```[\s\S]*?```)')
    segments = code_block_re.split(text)
    for j, segment in enumerate(segments):
        if j % 2 == 1:
            # Code block — don't escape
            parts.append(segment)
        else:
            # Check for inline code
            inline_re = re.compile(r'(`[^`]+`)')
            inline_segments = inline_re.split(segment)
            for k, inline_seg in enumerate(inline_segments):
                if k % 2 == 1:
                    parts.append(inline_seg)
                else:
                    parts.append(escape_markdown_v2(inline_seg))
    return "".join(parts)
```

### `utils/meta_footer.py`
```python
from __future__ import annotations

def format_meta_footer(
    model_name: str,
    cost_usd: float,
    tokens: int,
    elapsed_seconds: float,
    fallback_used: bool = False,
) -> str:
    """Format the meta-footer for AI responses."""
    parts = [
        f"🤖 `{model_name}`",
        f"💳 `${cost_usd:.4f}`",
        f"⚡ `{tokens}` tok",
        f"⏱ `{elapsed_seconds:.1f}s`",
    ]
    if fallback_used:
        parts.append("⚠️ Fallback")
    return "\n\n───\n" + " | ".join(parts)
```

### `utils/message_splitter.py`
```python
from __future__ import annotations

MAX_MESSAGE_LENGTH = 4096
SAFE_LIMIT = 4000  # Leave room for formatting

def split_message(text: str, limit: int = SAFE_LIMIT) -> list[str]:
    """Split text into chunks respecting code blocks and sentences."""
    if len(text) <= limit:
        return [text]

    chunks: list[str] = []
    remaining = text

    while remaining:
        if len(remaining) <= limit:
            chunks.append(remaining)
            break

        # Find a good split point
        split_at = limit

        # Don't split inside code blocks
        code_start = remaining.rfind("```", 0, split_at)
        code_end = remaining.rfind("```", 0, split_at)
        # Count backtick triples to determine if we're inside a code block
        triple_count = remaining[:split_at].count("```")
        if triple_count % 2 == 1:
            # Inside code block — find the opening ``` and split before it
            last_open = remaining.rfind("```", 0, split_at)
            if last_open > 0:
                split_at = last_open

        # Try to split at sentence boundary
        for sep in ["\n\n", "\n", ". ", "! ", "? ", ", ", " "]:
            pos = remaining.rfind(sep, 0, split_at)
            if pos > limit // 2:
                split_at = pos + len(sep)
                break

        chunk = remaining[:split_at].rstrip()
        remaining = remaining[split_at:].lstrip()

        if chunk:
            chunks.append(chunk)

    return chunks if chunks else [text]

def should_send_as_file(text: str) -> bool:
    """Returns True if response should be sent as a file instead of messages."""
    # If text is very long with code blocks
    if len(text) > 8000 and "```" in text:
        return True
    # If there are multiple large code blocks
    code_blocks = text.count("```")
    if code_blocks >= 4 and len(text) > 6000:
        return True
    return False
```

### `requirements.txt`
```
python-telegram-bot[webhooks]==21.7
httpx>=0.27.0
pydantic>=2.5.0
pydantic-settings>=2.1.0
python-dotenv>=1.0.0
pydub>=0.25.1
PyPDF2>=3.0.0
python-docx>=1.1.0
aiofiles>=23.2.0
```

### `pytest.ini`
```ini
[pytest]
testpaths = tests
asyncio_mode = auto
```

### Verification:
```bash
cd ai-aggregator-updated && python -c "from config import settings; print('Config OK')"
cd ai-aggregator-updated && python -c "from services.base import BaseService; print('BaseService OK')"
cd ai-aggregator-updated && python -c "from utils.formatters import escape_markdown_v2; print(escape_markdown_v2('test_hello')); print('Formatters OK')"
cd ai-aggregator-updated && python -c "from utils.meta_footer import format_meta_footer; print(format_meta_footer('gemini-flash', 0.0012, 340, 1.2)); print('Footer OK')"
cd ai-aggregator-updated && python -c "from utils.message_splitter import split_message; assert len(split_message('x' * 8000)) > 1; print('Splitter OK')"
cd ai-aggregator-updated && python -c "from services.provider_normalization import canonical_provider; assert canonical_provider('gpt') == 'openai'; assert canonical_provider('claude-sonnet') == 'claude'; print('Normalization OK')"
cd ai-aggregator-updated && pytest tests/test_config.py tests/test_provider_normalization.py tests/test_formatters.py tests/test_meta_footer.py tests/test_message_splitter.py -v
```

---

## PHASE 2: Services Layer

**Files to create:**
- `services/auth_service.py`
- `services/chat_service.py`
- `services/rag_service.py`
- `services/analytics_service.py`
- `services/image_service.py`
- `services/agent_service.py`
- `services/admin_service.py`
- `services/provider_policy_service.py`
- `tests/test_services.py`
- `tests/test_provider_policy.py`

### `services/chat_service.py` (KEY — includes fallback logic)
```python
from __future__ import annotations
import time
import logging
from services.base import BaseService, AllProvidersFailedError, RateLimitError, BackendTimeoutError, BackendUnavailableError

logger = logging.getLogger(__name__)

DEFAULT_FALLBACK_CHAIN = ["gemini", "deepseek", "groq", "mistral", "openrouter", "grok", "claude", "openai"]

class ChatService(BaseService):
    async def send_message(
        self,
        user_id: str,
        token: str,
        prompt: str,
        conversation_id: str | None = None,
        use_rag: bool = False,
    ) -> dict:
        """Send chat message to backend. Returns full response with metadata."""
        payload = {
            "user_id": user_id,
            "prompt": prompt,
            "use_rag": use_rag,
        }
        if conversation_id:
            payload["conversation_id"] = conversation_id
        start = time.monotonic()
        result = await self._request("POST", "/api/chat/", token=token, json=payload)
        result["_elapsed"] = time.monotonic() - start
        return result

    async def get_providers(self) -> list[str]:
        """Get list of available providers from backend."""
        return await self._request("GET", "/api/chat/providers")

    async def send_with_provider(
        self,
        user_id: str,
        token: str,
        prompt: str,
        provider: str,
        conversation_id: str | None = None,
    ) -> dict:
        """Send message with explicit provider command prefix."""
        full_prompt = f"/{provider} {prompt}" if not prompt.startswith(f"/{provider}") else prompt
        return await self.send_message(user_id, token, full_prompt, conversation_id)
```

Each service class follows the same pattern — inherits BaseService, wraps backend API calls with proper error handling. Implement ALL endpoints from the API spec above.

### Verification:
```bash
cd ai-aggregator-updated && pytest tests/test_services.py tests/test_provider_policy.py -v
```

---

## PHASE 3: Handlers — Core Chat

**Files to create:**
- `handlers/__init__.py` — `register_all_handlers(app)` function
- `handlers/start.py`
- `handlers/help.py`
- `handlers/chat.py` — main text message handler
- `handlers/commands.py` — model switching commands
- `handlers/settings_cmd.py`
- `handlers/errors.py` — global error handler
- `middleware/typing_indicator.py`
- `keyboards/model_selector.py`
- `keyboards/settings_keyboard.py`
- `tests/test_handlers.py`

### Handler Pattern (EVERY handler follows this):
```python
async def some_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not update.message or not update.effective_user:
        return

    # 1. Auth check
    if not _is_allowed(update.effective_user.id):
        return  # silently ignore unauthorized users

    # 2. Get services from bot_data
    chat_service: ChatService = context.bot_data["chat_service"]
    auth_service: AuthService = context.bot_data["auth_service"]

    # 3. Authenticate (with retry)
    try:
        result = await with_auth_retry(
            lambda uid, tok: chat_service.send_message(uid, tok, text),
            update, context, auth_service,
        )
    except RateLimitError as e:
        await update.message.reply_text(f"🚫 {e}")
        return
    except BackendUnavailableError:
        await update.message.reply_text("⚠️ Serwer AI jest chwilowo niedostępny.")
        return

    # 4. Format response with meta-footer
    # 5. Split if needed
    # 6. Send with MarkdownV2 (fallback to plain text on parse error)
```

### `handlers/chat.py` — MAIN HANDLER
Must include:
1. Typing indicator (async task that sends TYPING every 4s)
2. Auth retry via middleware
3. Meta-footer on every response
4. Message splitting for long responses
5. Send as file for very long code responses
6. MarkdownV2 with fallback to plain text
7. Conversation ID tracking in `context.user_data`
8. Elapsed time measurement

### `handlers/commands.py` — MODEL SWITCHING
Pattern: `/claude some question` → switch to claude AND send the question
Pattern: `/claude` (alone) → just switch default model, confirm with message

### `handlers/__init__.py`
```python
from telegram.ext import Application, CommandHandler, MessageHandler, InlineQueryHandler, CallbackQueryHandler, filters

def register_all_handlers(app: Application) -> None:
    """Register all bot handlers in correct priority order."""
    from handlers import start, help, commands, chat, settings_cmd, usage, plan
    from handlers import voice, documents, images, rag, admin, inline, callbacks
    from handlers import notebook, workspace, memory, repurpose, errors

    # Commands (highest priority)
    app.add_handler(CommandHandler("start", start.handle))
    app.add_handler(CommandHandler("help", help.handle))
    app.add_handler(CommandHandler("settings", settings_cmd.handle))
    app.add_handler(CommandHandler("usage", usage.handle))
    app.add_handler(CommandHandler("plan", plan.handle))
    app.add_handler(CommandHandler("memory", memory.handle_memory))
    app.add_handler(CommandHandler("forget", memory.handle_forget))
    app.add_handler(CommandHandler("new", memory.handle_new_conversation))
    app.add_handler(CommandHandler("export", memory.handle_export))
    app.add_handler(CommandHandler("imagine", images.handle))
    app.add_handler(CommandHandler("rag", rag.handle_search))
    app.add_handler(CommandHandler("upload", rag.handle_upload_command))
    app.add_handler(CommandHandler("notebook", notebook.handle))
    app.add_handler(CommandHandler("workspace", workspace.handle_list))
    app.add_handler(CommandHandler("download", workspace.handle_download))
    app.add_handler(CommandHandler("repurpose", repurpose.handle))
    app.add_handler(CommandHandler("admin", admin.handle))

    # Model commands
    for cmd in ["claude", "gpt", "gemini", "deepseek", "groq", "mistral", "grok", "openrouter"]:
        app.add_handler(CommandHandler(cmd, commands.handle_model_command))

    # Inline mode
    app.add_handler(InlineQueryHandler(inline.handle))

    # Callback queries (inline keyboards)
    app.add_handler(CallbackQueryHandler(callbacks.handle))

    # Voice messages
    app.add_handler(MessageHandler(filters.VOICE | filters.AUDIO, voice.handle))

    # Document uploads
    app.add_handler(MessageHandler(filters.Document.ALL, documents.handle))

    # Regular text (lowest priority)
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, chat.handle))

    # Error handler
    app.add_error_handler(errors.handle_error)
```

### Verification:
```bash
cd ai-aggregator-updated && python -c "from handlers import register_all_handlers; print('Handlers OK')"
cd ai-aggregator-updated && pytest tests/test_handlers.py -v
```

---

## PHASE 4: Advanced Handlers

**Files to create:**
- `handlers/voice.py`
- `handlers/documents.py`
- `handlers/images.py`
- `handlers/rag.py`
- `handlers/usage.py`
- `handlers/plan.py`
- `handlers/admin.py`
- `handlers/inline.py`
- `handlers/callbacks.py`
- `handlers/notebook.py`
- `handlers/workspace.py`
- `handlers/memory.py`
- `handlers/repurpose.py`
- `utils/file_processor.py`
- `utils/voice_processor.py`
- `keyboards/main_menu.py`
- `keyboards/plan_keyboard.py`
- `keyboards/pagination.py`
- `middleware/rate_limit.py`

### Key implementations:

**`handlers/voice.py`**: Download OGG → convert to WAV with pydub → send to backend STT endpoint (or use OpenAI Whisper via backend) → get text → run through normal chat flow → respond with text

**`handlers/documents.py`**: Accept PDF/DOCX/TXT/ZIP → extract text locally (PyPDF2/python-docx) → upload to backend RAG → confirm with filename + page count

**`handlers/admin.py`**: Parse subcommands (`/admin stats`, `/admin users`, `/admin costs`) → call admin_service → format as nice Telegram message with stats

**`handlers/inline.py`**: InlineQueryHandler → get query → fan out to 3 providers (asyncio.gather) → return InlineQueryResultArticle for each with model name as title

**`handlers/notebook.py`**: Toggle notebook mode in `context.user_data["notebook_mode"]` → when active, force provider to "groq" → mark responses as ephemeral (don't save to conversation)

**`handlers/repurpose.py`**: Take text → send to AI with system prompt "Rewrite this as: 1) LinkedIn post, 2) Twitter/X thread, 3) Facebook post, 4) Instagram caption" → return formatted versions

### Verification:
```bash
cd ai-aggregator-updated && python -c "
from handlers import voice, documents, images, rag, usage, plan, admin
from handlers import inline, callbacks, notebook, workspace, memory, repurpose
print('All advanced handlers imported OK')
"
cd ai-aggregator-updated && pytest tests/ -v
```

---

## PHASE 5: Bot Entry Point + Docker

**Files to create:**
- `bot.py`
- `Dockerfile`
- `docker-compose.yml`

### `bot.py`
```python
from __future__ import annotations
import logging
import sys
import json
from telegram.ext import ApplicationBuilder
from config import settings
from handlers import register_all_handlers
from services.auth_service import AuthService
from services.chat_service import ChatService
from services.rag_service import RagService
from services.analytics_service import AnalyticsService
from services.image_service import ImageService
from services.agent_service import AgentService
from services.admin_service import AdminService
from services.provider_policy_service import ProviderPolicyService

# JSON logging
class JsonFormatter(logging.Formatter):
    def format(self, record):
        return json.dumps({
            "time": self.formatTime(record),
            "level": record.levelname,
            "name": record.name,
            "message": record.getMessage(),
            **({"exception": self.formatException(record.exc_info)} if record.exc_info else {}),
        })

handler = logging.StreamHandler(sys.stdout)
handler.setFormatter(JsonFormatter() if settings.log_json else logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s"))
logging.basicConfig(level=getattr(logging, settings.log_level), handlers=[handler])

logger = logging.getLogger(__name__)

def main() -> None:
    app = ApplicationBuilder().token(settings.telegram_bot_token).build()

    # Initialize services
    base_url = settings.backend_url
    auth_service = AuthService(base_url)
    chat_service = ChatService(base_url)
    rag_service = RagService(base_url)
    analytics_service = AnalyticsService(base_url)
    image_service = ImageService(base_url)
    agent_service = AgentService(base_url)
    admin_service = AdminService(base_url)
    policy_service = ProviderPolicyService.from_env()

    # Store in bot_data for handler access
    app.bot_data["auth_service"] = auth_service
    app.bot_data["chat_service"] = chat_service
    app.bot_data["rag_service"] = rag_service
    app.bot_data["analytics_service"] = analytics_service
    app.bot_data["image_service"] = image_service
    app.bot_data["agent_service"] = agent_service
    app.bot_data["admin_service"] = admin_service
    app.bot_data["policy_service"] = policy_service
    app.bot_data["settings"] = settings

    # Register handlers
    register_all_handlers(app)

    # Shutdown hook
    async def on_shutdown(_):
        for svc in [auth_service, chat_service, rag_service, analytics_service, image_service, agent_service, admin_service]:
            await svc.close()

    app.post_shutdown.append(on_shutdown)

    # Start
    if settings.is_webhook_mode:
        logger.info("Starting webhook mode on port %d", settings.webhook_port)
        app.run_webhook(
            listen="0.0.0.0",
            port=settings.webhook_port,
            url_path=settings.webhook_path,
            webhook_url=f"{settings.webhook_url.rstrip('/')}/{settings.webhook_path}",
            secret_token=settings.webhook_secret_token or None,
        )
    else:
        logger.info("Starting polling mode")
        app.run_polling()

if __name__ == "__main__":
    main()
```

### `Dockerfile`
```dockerfile
FROM python:3.12-slim
RUN apt-get update && apt-get install -y --no-install-recommends ffmpeg && rm -rf /var/lib/apt/lists/*
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
HEALTHCHECK --interval=30s --timeout=5s CMD python -c "import sys; sys.exit(0)"
CMD ["python", "bot.py"]
```

### `docker-compose.yml`
```yaml
version: "3.8"
services:
  telegram-bot:
    build: .
    restart: unless-stopped
    env_file: .env
    depends_on:
      - redis
    volumes:
      - bot-data:/app/data
  redis:
    image: redis:7-alpine
    restart: unless-stopped
    volumes:
      - redis-data:/data
volumes:
  bot-data:
  redis-data:
```

### `.env.example`
```bash
# Required
TELEGRAM_BOT_TOKEN=your_bot_token_here
BACKEND_URL=http://backend:8000

# Access control (comma-separated Telegram user IDs)
ALLOWED_TELEGRAM_USER_IDS=8236214480,8164622121,577356488,8554224381
ADMIN_USER_IDS=8236214480,8164622121,577356488

# Mode
TELEGRAM_MODE=polling
# WEBHOOK_URL=https://your-domain.com
# WEBHOOK_PORT=8443
# WEBHOOK_SECRET_TOKEN=your_secret

# Provider Policy (JSON)
PROVIDER_POLICY_JSON={"default":{"providers":{"gemini":{"enabled":true},"deepseek":{"enabled":true},"groq":{"enabled":true,"daily_usd_cap":1.0},"claude":{"enabled":true,"daily_usd_cap":5.0},"openai":{"enabled":true,"daily_usd_cap":5.0}}},"users":{"8554224381":{"providers":{"openai":{"enabled":false},"claude":{"enabled":false}}}}}

# Features
VOICE_ENABLED=true
INLINE_ENABLED=true
IMAGE_GEN_ENABLED=true
NOTEBOOK_MODE_ENABLED=true

# Logging
LOG_LEVEL=INFO
LOG_JSON=true
```

### Verification:
```bash
cd ai-aggregator-updated && python -c "from bot import main; print('Bot entry point OK')"
cd ai-aggregator-updated && docker build -t jarvis-bot-test . 2>&1 | tail -5
cd ai-aggregator-updated && pytest tests/ -v --tb=short
```

---

## PHASE 6: Integration Tests

**Files to create/expand:**
- `tests/test_middleware_auth.py`
- `tests/test_handlers.py` (expand)
- `tests/test_message_splitter.py`

### Test requirements:
1. **test_config.py**: Validate settings load, defaults, property access
2. **test_provider_normalization.py**: All aliases map correctly, unknown names pass through
3. **test_provider_policy.py**: Policy loading from JSON, merge logic, budget checks, chain filtering
4. **test_formatters.py**: MarkdownV2 escaping, code block preservation
5. **test_meta_footer.py**: Footer format, fallback indicator
6. **test_message_splitter.py**: Splitting at limits, code block preservation, file detection
7. **test_services.py**: Mock httpx responses, verify error class hierarchy
8. **test_middleware_auth.py**: Auth flow, retry on 401, token caching
9. **test_handlers.py**: Mock update/context, verify handler routing

### Verification (final):
```bash
cd ai-aggregator-updated && pytest tests/ -v --tb=short -q
cd ai-aggregator-updated && python -m py_compile bot.py && echo "Compiles OK"
cd ai-aggregator-updated && find . -name "*.py" -exec python -m py_compile {} \; && echo "All files compile"
```

---

## FINAL CHECKLIST

Before creating the PR, verify:

- [ ] All files exist per the repository structure above
- [ ] ZERO TODO/placeholder in any file (grep -r "TODO\|FIXME\|pass$\|\\.\\.\\." --include="*.py")
- [ ] Every handler has error handling + auth retry
- [ ] Every AI response includes meta-footer
- [ ] Message splitting works (messages > 4096 chars)
- [ ] MarkdownV2 fallback to plain text on parse error
- [ ] Provider policy service loads from env
- [ ] Config validates on import
- [ ] All tests pass
- [ ] Docker builds successfully
- [ ] .env.example has ALL required vars
- [ ] requirements.txt is complete

```bash
# Final validation
cd ai-aggregator-updated
grep -rn "TODO\|FIXME\|# implement\|pass$" --include="*.py" | grep -v "test_\|conftest" | wc -l
# Expected: 0

pytest tests/ -v
# Expected: All pass

python -c "
from config import settings
from services.base import BaseService
from services.provider_normalization import canonical_provider
from services.provider_policy_service import ProviderPolicyService
from utils.formatters import escape_markdown_v2, safe_markdown_v2
from utils.meta_footer import format_meta_footer
from utils.message_splitter import split_message, should_send_as_file
from handlers import register_all_handlers
print('ALL IMPORTS OK — READY FOR PR')
"
```

---

## PR DESCRIPTION

```markdown
## AI Aggregator Telegram Bot v2.0

Complete rewrite of the Telegram bot client for AI Aggregator backend.

### Features
- 8 AI providers (Gemini, Claude, GPT-4, DeepSeek, Groq, Mistral, OpenRouter, Grok)
- Per-user provider policy with USD-based daily/monthly quotas
- Automatic fallback chain (gemini → deepseek → groq → ... → openai)
- Meta-footer on every AI response (model, cost, tokens, time)
- Smart message splitting (respects code blocks, sends files for very long responses)
- MarkdownV2 formatting with plain-text fallback
- Voice message support (OGG → WAV → STT → AI)
- Document upload to RAG knowledge base
- Image generation (/imagine)
- Inline mode (query from any chat)
- Admin panel (/admin stats/users/costs)
- Notebook mode (cheap Groq for casual chat)
- Usage statistics and tier management
- Content repurposer (/repurpose → social media posts)
- Docker + docker-compose ready

### Architecture
- Thin client pattern — all AI logic lives in FastAPI backend
- Service-per-domain pattern with shared BaseService
- Auth middleware with automatic token refresh
- Structured JSON logging
- Full test suite
```
