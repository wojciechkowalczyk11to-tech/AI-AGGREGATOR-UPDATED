# JULES TASK: Build AI Aggregator Telegram Bot from scratch

## INSTRUCTIONS

You are building a complete Telegram bot repository from an empty repo.

**Read the attached CODEX_MEGA_PROMPT.md FIRST — it is your full specification.**
**The attached telegram_bot_extract.zip is REFERENCE ONLY — do NOT copy files. Use it to understand patterns and API contracts.**

## EXECUTION ORDER

Build the entire repository in this exact order (phases from the spec):

1. **Phase 1:** Config, base service, utils, provider normalization + tests
2. **Phase 2:** All 8 services (auth, chat, rag, analytics, image, agent, admin, provider_policy) + tests
3. **Phase 3:** Middleware (auth, rate_limit, logging, typing_indicator) + keyboards + tests
4. **Phase 4:** Core handlers (start, help, chat, commands, settings, errors) + handler registry + tests
5. **Phase 5:** Advanced handlers (voice, documents, images, rag, usage, plan, admin, inline, callbacks, notebook, workspace, memory, repurpose)
6. **Phase 6:** bot.py entry point, Dockerfile, docker-compose.yml, requirements.txt, README.md, final validation

## NON-NEGOTIABLE RULES

- **ZERO TODO, ZERO placeholder, ZERO `pass` without logic, ZERO `...`, ZERO `# implement later`**
- Every file must be complete and production-ready
- `from __future__ import annotations` in every Python file
- Full error handling: try/except on every handler, retry on 401, graceful degradation
- Docstrings on every class and public function
- All env vars via Pydantic BaseSettings (config.py), no hardcoded secrets
- Tests must actually test logic, not just `assert True`

## REPO STRUCTURE

Repository name: `ai-aggregator-updated`
All files go in the root of this repo (NOT inside a subdirectory).
The full file tree is in CODEX_MEGA_PROMPT.md — follow it exactly.

## VERIFICATION (run after completion)

```bash
# No TODOs or placeholders
grep -rn "TODO\|FIXME\|pass$\|\.\.\.\"" --include="*.py" | wc -l  # Must be 0

# All files compile
find . -name "*.py" -exec python -m py_compile {} \;

# Config loads
python -c "from config import settings; print('OK')"

# Normalization works
python -c "from utils.provider_normalization import canonical_provider; assert canonical_provider('gpt') == 'openai'; assert canonical_provider('grok') == 'grok'; assert canonical_provider('groq') == 'groq'; print('OK')"

# Tests pass
pytest tests/ -v --tb=short
```

## CRITICAL REMINDERS

- **grok ≠ groq** — these are SEPARATE providers. grok = xAI, groq = Groq Inc.
- This bot is a **thin client** — it does NOT have a database. All data goes through the FastAPI backend via httpx.
- Meta-footer (`🤖 model | 💳 $cost | ⚡ tokens | ⏱ time`) on EVERY AI response — no exceptions.
- Message splitting at 4096 chars respecting code blocks.
- MarkdownV2 with fallback to plain text on parse errors.
- Polish error messages for users.

Now read CODEX_MEGA_PROMPT.md and build the complete repository.
