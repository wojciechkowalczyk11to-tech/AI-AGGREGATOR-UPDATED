"""
Add rate limiter dependency.
"""

from typing import Optional
from backend.middleware.rate_limiter import RateLimiter

# Global rate limiter instance
_rate_limiter: Optional[RateLimiter] = None


async def get_rate_limiter() -> RateLimiter:
    """Get rate limiter instance."""
    global _rate_limiter
    if not _rate_limiter:
        _rate_limiter = RateLimiter(redis_url="redis://redis:6379")
        await _rate_limiter.connect()
    return _rate_limiter
