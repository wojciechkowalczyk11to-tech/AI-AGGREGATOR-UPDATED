from __future__ import annotations

import logging
import re
from telegram import Update
from telegram.constants import ChatAction
from telegram.ext import ContextTypes

from telegram_bot.config import settings
from telegram_bot.services import BackendService, BackendServiceError, AuthenticationError, ClientError

WELCOME_MESSAGE = (
    "Welcome to AI Aggregator Bot!\n"
    "Send me a message and I'll forward it to the AI backend.\n"
    "You can use slash commands like /claude, /gpt, /gemini to switch providers."
)

SETTINGS_MESSAGE = (
    "Open the mobile app to adjust your settings: "
    "Use the deep link or open the app from your device."
)

HELP_MESSAGE = (
    "Available commands:\n"
    "/start - Register and get started\n"
    "/settings - Open mobile app settings\n"
    "/help - Show this help message\n\n"
    "Supported AI Providers (use as /provider):\n"
)

# Regex to detect command-only messages (e.g., "/claude" or "/claude ")
# Captures the command name (provider)
COMMAND_ONLY_PATTERN = re.compile(r"^/(?P<command>[a-zA-Z0-9_-]+)\s*$")


def _check_auth(update: Update) -> bool:
    """Check if the user is authorized to use the bot."""
    if update.effective_user is None:
        return False

    # If allowlist is configured, enforce it.
    # If empty, we deny all for security (as per strict owner-only requirement).
    allowed = settings.allowed_telegram_user_ids
    if not allowed or update.effective_user.id not in allowed:
        logging.warning(f"telegram_denied user_id={update.effective_user.id}")
        return False
    return True


def _get_backend_service(context: ContextTypes.DEFAULT_TYPE) -> BackendService:
    return context.bot_data["backend_service"]


async def _get_or_register_user(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
    backend: BackendService,
    force_refresh: bool = False,
) -> tuple[str, str] | None:
    """Returns (backend_user_id, access_token) or None."""
    backend_user_id = context.user_data.get("backend_user_id")
    access_token = context.user_data.get("access_token")

    if backend_user_id and access_token and not force_refresh:
        return backend_user_id, access_token

    if update.effective_user is None:
        return None

    try:
        # Re-registering creates the user if missing, or returns existing user with NEW token
        payload = await backend.register_user(update.effective_user.id)
        backend_user_id = str(payload.get("id"))
        access_token = payload.get("access_token")

        if backend_user_id and access_token:
            context.user_data["backend_user_id"] = backend_user_id
            context.user_data["access_token"] = access_token
            return backend_user_id, access_token
    except BackendServiceError:
        pass

    return None


async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if update.message is None:
        return

    if not _check_auth(update):
        return

    backend = _get_backend_service(context)
    try:
        creds = await _get_or_register_user(update, context, backend)
        if creds:
            await update.message.reply_text(WELCOME_MESSAGE)
        else:
             await update.message.reply_text("Could not register user.")
    except BackendServiceError:
        await update.message.reply_text(
            "Sorry, we're having trouble reaching the backend. Please try again later."
        )


async def settings_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if update.message is None:
        return

    if not _check_auth(update):
        return

    await update.message.reply_text(SETTINGS_MESSAGE)


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if update.message is None:
        return

    if not _check_auth(update):
        return

    backend = _get_backend_service(context)
    try:
        providers = await backend.get_supported_providers()
        provider_list = ", ".join(f"/{p}" for p in providers)
        await update.message.reply_text(f"{HELP_MESSAGE}{provider_list}")
    except BackendServiceError:
        await update.message.reply_text(f"{HELP_MESSAGE}(Could not fetch providers)")


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if (
        update.message is None
        or update.effective_user is None
        or update.effective_chat is None
    ):
        return

    if not _check_auth(update):
        return

    backend = _get_backend_service(context)

    # 1. Get credentials
    creds = await _get_or_register_user(update, context, backend)
    if not creds:
        await update.message.reply_text(
            "Unable to identify your account. Please try /start again."
        )
        return

    user_id, token = creds
    text = update.message.text or ""

    # 2. Check for "Command Only" (setting update)
    match = COMMAND_ONLY_PATTERN.match(text)
    if match:
        provider = match.group("command")
        # Attempt to update settings
        try:
            await backend.update_settings(
                user_id=user_id,
                access_token=token,
                settings={"preferred_model": provider}
            )
            await update.message.reply_text(f"Switched to {provider}. Send message...")
        except AuthenticationError:
             # Retry logic for auth error during settings update
            creds = await _get_or_register_user(update, context, backend, force_refresh=True)
            if not creds:
                 await update.message.reply_text("Authentication failed. Please /start again.")
                 return
            user_id, token = creds
            try:
                await backend.update_settings(
                    user_id=user_id,
                    access_token=token,
                    settings={"preferred_model": provider}
                )
                await update.message.reply_text(f"Switched to {provider}. Send message...")
            except BackendServiceError:
                 await update.message.reply_text("Sorry, failed to update settings.")
        except ClientError:
            # Backend might return 400 if we had validation there?
            # Currently settings update endpoint is generic JSON, doesn't validate provider strictly unless model enforces.
            # But let's assume it works or generic error.
            # Ideally we check against supported list first or handle error.
            # But for now, generic handling.
            await update.message.reply_text("Could not switch provider (Client Error).")
        except BackendServiceError:
             await update.message.reply_text("Sorry, failed to update settings.")
        return

    # 3. Regular Chat Message
    conversation_id = context.user_data.get("conversation_id")

    await context.bot.send_chat_action(
        chat_id=update.effective_chat.id,
        action=ChatAction.TYPING,
    )

    try:
        payload = await backend.send_message(
            user_id=user_id,
            access_token=token,
            prompt=text,
            conversation_id=conversation_id,
        )
    except AuthenticationError:
        # Retry once with refresh
        creds = await _get_or_register_user(update, context, backend, force_refresh=True)
        if not creds:
             await update.message.reply_text("Authentication failed. Please /start again.")
             return
        user_id, token = creds
        try:
             payload = await backend.send_message(
                user_id=user_id,
                access_token=token,
                prompt=text,
                conversation_id=conversation_id,
            )
        except BackendServiceError:
             await update.message.reply_text("Sorry, something went wrong after re-authenticating.")
             return

    except ClientError as e:
        # 400 Errors (Unknown provider, etc)
        await update.message.reply_text(str(e))
        return
    except BackendServiceError:
        await update.message.reply_text(
            "Sorry, the backend is currently unavailable. Please try again later."
        )
        return

    # 4. Process success response
    response_text = payload.get("response", "")
    model_name = payload.get("model_name")
    provider = payload.get("provider")

    # Format prefix: use model_name if available, else provider
    prefix = model_name if model_name else provider
    if not prefix:
        prefix = "Assistant"

    formatted_reply = f"{prefix}: {response_text}"

    # Update conversation context
    new_conv_id = payload.get("conversation_id")
    if new_conv_id:
        context.user_data["conversation_id"] = new_conv_id

    await update.message.reply_text(formatted_reply)


async def unknown_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if update.message:
        await update.message.reply_text("Unknown command. Use /help to see available commands.")
