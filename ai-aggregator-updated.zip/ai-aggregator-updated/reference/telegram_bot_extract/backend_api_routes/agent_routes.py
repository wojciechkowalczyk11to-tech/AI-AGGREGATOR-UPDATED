from __future__ import annotations

import os
import uuid
from datetime import datetime, timezone

import httpx
from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Request, status
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.agents.code_agent import CodeAgent
from backend.api.deps import get_current_user, get_db
from backend.services.usage_service import UsageService
from backend.webhooks import extract_pr_numbers
from backend.agents.github_client import GitHubClient
from backend.agents.pr_manager import PRManager
from backend.database import AsyncSessionLocal
from backend.models import AgentTask, GitHubToken, User
from backend.models.agent_task import AgentTaskStatus
from backend.utils.encryption import decrypt_token, encrypt_token
from backend.utils.rate_limiter import AgentTaskLimiter

router = APIRouter(prefix="/agent", tags=["agent"])
webhook_router = APIRouter(tags=["webhooks"])


class GitHubConnectRequest(BaseModel):
    code: str = Field(..., min_length=1)


class AgentTaskRequest(BaseModel):
    repo_name: str = Field(..., min_length=1)
    description: str = Field(..., min_length=1)
    model: str = Field(..., min_length=1)


class AgentTaskResponse(BaseModel):
    id: str
    repo_name: str
    description: str
    status: AgentTaskStatus
    pr_url: str | None
    ci_checks: list[dict[str, object]]


async def _require_github_token(db: AsyncSession, user: User) -> str:
    result = await db.execute(
        select(GitHubToken).where(GitHubToken.user_id == user.id)
    )
    token = result.scalar_one_or_none()
    if token is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="GitHub token not found for user",
        )
    try:
        return decrypt_token(token.encrypted_token)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="GitHub token decryption is not configured",
        ) from exc


async def _load_task(
    db: AsyncSession, task_id: str, user: User
) -> AgentTask | None:
    try:
        task_uuid = uuid.UUID(task_id)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Task not found"
        ) from exc
    result = await db.execute(
        select(AgentTask).where(
            AgentTask.id == task_uuid, AgentTask.user_id == user.id
        )
    )
    return result.scalar_one_or_none()


def _extract_pr_number(pr_url: str | None) -> int | None:
    if not pr_url:
        return None
    parts = pr_url.rstrip("/").split("/")
    if not parts:
        return None
    try:
        return int(parts[-1])
    except ValueError:
        return None


async def _get_ci_checks(
    repo_name: str, pr_url: str | None, token: str
) -> list[dict[str, object]]:
    pr_number = _extract_pr_number(pr_url)
    if pr_number is None:
        return []
    if "/" not in repo_name:
        return []
    owner, repo = repo_name.split("/", 1)
    async with GitHubClient(token) as github_client:
        pr = await github_client.get_pull_request(owner, repo, pr_number)
        head_sha = pr.get("head", {}).get("sha")
        if not head_sha:
            return []
        check_runs = await github_client.list_check_runs(owner, repo, head_sha)
        return list(check_runs)


async def _run_agent_task(
    task_id: str,
    user_id: uuid.UUID,
    repo_name: str,
    description: str,
    token: str,
    model: str,
) -> None:
    async with AsyncSessionLocal() as db:
        try:
            if "/" not in repo_name:
                raise ValueError("Repository name must be in owner/repo format")
            owner, repo = repo_name.split("/", 1)
            async with GitHubClient(token) as github_client:
                agent = CodeAgent(github_client, provider_name=model)
                changes, response = await agent.execute_task(
                    task_id=task_id,
                    owner=owner,
                    repo=repo,
                    description=description,
                )

                # Log usage
                await UsageService.log_request(
                    session=db,
                    user_id=user_id,
                    provider=model, # Model name is passed as provider_name in CodeAgent
                    model=response.model_name,
                    input_tokens=response.input_tokens,
                    output_tokens=response.output_tokens,
                    cost=response.cost_usd,
                )

                manager = PRManager(
                    github_client,
                    db,
                    owner=owner,
                    repo=repo,
                )
                await manager.create_pr_for_task(task_id, changes)
        except Exception:
            try:
                task_uuid = uuid.UUID(task_id)
            except ValueError:
                return
            result = await db.execute(
                select(AgentTask).where(AgentTask.id == task_uuid)
            )
            task = result.scalar_one_or_none()
            if task is not None:
                task.status = AgentTaskStatus.FAILED
                await db.commit()


async def exchange_code_for_token(code: str) -> str:
    client_id = os.getenv("GITHUB_CLIENT_ID")
    client_secret = os.getenv("GITHUB_CLIENT_SECRET")
    if not client_id or not client_secret:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="GitHub OAuth configuration is missing",
        )

    payload = {"client_id": client_id, "client_secret": client_secret, "code": code}
    headers = {"Accept": "application/json"}

    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                "https://github.com/login/oauth/access_token",
                data=payload,
                headers=headers,
                timeout=10.0,
            )
    except httpx.RequestError as exc:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail="Failed to reach GitHub OAuth service",
        ) from exc

    if response.status_code in {401, 403, 404}:
        raise HTTPException(
            status_code=response.status_code,
            detail="GitHub OAuth rejected the request",
        )
    if response.status_code >= 400:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail="GitHub OAuth exchange failed",
        )

    data = response.json()
    access_token = data.get("access_token")
    if not access_token:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail="GitHub OAuth did not return an access token",
        )
    return access_token


@router.post("/connect-github", status_code=status.HTTP_201_CREATED)
async def connect_github(
    payload: GitHubConnectRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict[str, str]:
    access_token = await exchange_code_for_token(payload.code)
    try:
        encrypted_token = encrypt_token(access_token)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Token encryption is not configured",
        ) from exc

    result = await db.execute(
        select(GitHubToken).where(GitHubToken.user_id == current_user.id)
    )
    existing = result.scalar_one_or_none()

    if existing:
        existing.encrypted_token = encrypted_token
        existing.created_at = datetime.now(timezone.utc)
    else:
        db.add(
            GitHubToken(
                user_id=current_user.id,
                encrypted_token=encrypted_token,
            )
        )

    await db.commit()
    return {"status": "connected"}


@router.get("/repositories")
async def list_repositories(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> list[dict[str, object]]:
    token = await _require_github_token(db, current_user)
    async with GitHubClient(token) as github_client:
        repos = await github_client.list_repos()
    return [
        {
            "id": repo.get("id"),
            "name": repo.get("name"),
            "full_name": repo.get("full_name"),
        }
        for repo in repos
    ]


@router.post("/task", status_code=status.HTTP_202_ACCEPTED, dependencies=[Depends(AgentTaskLimiter)])
async def create_task(
    payload: AgentTaskRequest,
    background_tasks: BackgroundTasks,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict[str, str]:
    token = await _require_github_token(db, current_user)
    async with GitHubClient(token) as github_client:
        repos = await github_client.list_repos()
        repo_names = {repo.get("full_name") for repo in repos}
    if payload.repo_name not in repo_names:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Repository not found"
        )
    task = AgentTask(
        user_id=current_user.id,
        repo_name=payload.repo_name,
        description=payload.description,
        status=AgentTaskStatus.RUNNING,
    )
    db.add(task)
    await db.commit()
    await db.refresh(task)
    background_tasks.add_task(
        _run_agent_task,
        str(task.id),
        current_user.id,
        payload.repo_name,
        payload.description,
        token,
        payload.model,
    )
    return {"task_id": str(task.id)}


@router.get("/tasks/{task_id}", response_model=AgentTaskResponse)
async def get_task_status(
    task_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> AgentTaskResponse:
    token = await _require_github_token(db, current_user)
    task = await _load_task(db, task_id, current_user)
    if task is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Task not found"
        )
    ci_checks = await _get_ci_checks(task.repo_name, task.pr_url, token)
    return AgentTaskResponse(
        id=str(task.id),
        repo_name=task.repo_name,
        description=task.description,
        status=task.status,
        pr_url=task.pr_url,
        ci_checks=ci_checks,
    )


@router.get("/tasks", response_model=list[AgentTaskResponse])
async def list_tasks(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> list[AgentTaskResponse]:
    token = await _require_github_token(db, current_user)
    result = await db.execute(
        select(AgentTask).where(AgentTask.user_id == current_user.id)
    )
    tasks = result.scalars().all()
    responses: list[AgentTaskResponse] = []
    for task in tasks:
        ci_checks = await _get_ci_checks(task.repo_name, task.pr_url, token)
        responses.append(
            AgentTaskResponse(
                id=str(task.id),
                repo_name=task.repo_name,
                description=task.description,
                status=task.status,
                pr_url=task.pr_url,
                ci_checks=ci_checks,
            )
        )
    return responses


@webhook_router.post("/webhooks/github")
async def handle_github_webhook(
    request: Request,
    db: AsyncSession = Depends(get_db),
) -> dict[str, object]:
    payload = await request.json()
    pr_numbers = extract_pr_numbers(payload)
    if not pr_numbers:
        return {"status": "ignored"}
    repository = payload.get("repository", {})
    repo_name = repository.get("full_name")
    if not repo_name or "/" not in repo_name:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Repository information missing from webhook",
        )
    owner, repo = repo_name.split("/", 1)
    token = os.getenv("GITHUB_APP_TOKEN")
    if not token:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="GitHub app token is not configured",
        )
    async with GitHubClient(token) as github_client:
        manager = PRManager(github_client, db, owner=owner, repo=repo)
        for pr_number in pr_numbers:
            await manager.check_pr_status(pr_number)
    return {"status": "processed", "pull_requests": pr_numbers}
