import os
import re
from dotenv import load_dotenv

load_dotenv()

class TelegramSettings:
    def __init__(self):
        self.telegram_bot_token = os.getenv("TELEGRAM_BOT_TOKEN")
        self.backend_url = os.getenv("BACKEND_URL")
        self.mode = os.getenv("TELEGRAM_MODE", "polling").lower()
        self.webhook_url = os.getenv("WEBHOOK_URL")
        self.webhook_listen = os.getenv("WEBHOOK_LISTEN", "0.0.0.0")
        self.webhook_port = int(os.getenv("WEBHOOK_PORT", "8080"))
        self.webhook_path = os.getenv("WEBHOOK_PATH", "telegram")
        self.webhook_secret_token = os.getenv("WEBHOOK_SECRET_TOKEN")
        self.allowed_telegram_user_ids_str = os.getenv("ALLOWED_TELEGRAM_USER_IDS", "")

    def validate(self):
        """Validate required environment variables."""
        missing_vars = []

        if not self.telegram_bot_token:
            missing_vars.append("TELEGRAM_BOT_TOKEN")

        if not self.backend_url:
            missing_vars.append("BACKEND_URL")

        if self.mode == "webhook" and not self.webhook_url:
            missing_vars.append("WEBHOOK_URL")

        if missing_vars:
            raise RuntimeError(
                f"Missing required environment variables: {', '.join(missing_vars)}"
            )

        # Validate token format
        token_pattern = re.compile(r"^\d+:[A-Za-z0-9_-]{30,}$")
        if self.telegram_bot_token and not token_pattern.match(self.telegram_bot_token):
             raise ValueError("Invalid TELEGRAM_BOT_TOKEN format")

    @property
    def allowed_telegram_user_ids(self) -> list[int]:
        if not self.allowed_telegram_user_ids_str:
            return []
        try:
            return [
                int(uid.strip())
                for uid in self.allowed_telegram_user_ids_str.split(",")
                if uid.strip()
            ]
        except ValueError:
            return []


settings = TelegramSettings()
