from __future__ import annotations

import tempfile
import uuid
from datetime import datetime
from pathlib import Path
from typing import List

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile, status
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from backend.api.deps import get_current_user, get_db
from backend.models import Document, User
from backend.rag.retriever import RAGRetriever
from backend.utils.rate_limiter import RAGUploadLimiter

router = APIRouter(prefix="/rag", tags=["rag"])


class DocumentUploadResponse(BaseModel):
    id: uuid.UUID
    filename: str
    chromadb_collection_name: str
    created_at: datetime


class RagSearchRequest(BaseModel):
    query: str = Field(..., min_length=1)
    top_k: int = Field(default=5, ge=1, le=20)


class RagSearchResult(BaseModel):
    content: str = Field(alias="text") # map 'text' from retriever to 'content'
    score: float | None
    metadata: dict


class RagSearchResponse(BaseModel):
    results: List[RagSearchResult]


def get_retriever() -> RAGRetriever:
    return RAGRetriever()


@router.post("/upload", response_model=DocumentUploadResponse, status_code=status.HTTP_201_CREATED, dependencies=[Depends(RAGUploadLimiter)])
async def upload_document(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    retriever: RAGRetriever = Depends(get_retriever),
) -> Document:
    if not file.filename:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Missing filename")

    suffix = Path(file.filename).suffix
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as temp_file:
        contents = await file.read()
        temp_file.write(contents)
        temp_path = Path(temp_file.name)

    try:
        document_id = await retriever.upload_document(
            user_id=current_user.id,
            file_path=temp_path,
            filename=file.filename,
            db_session=db
        )
    finally:
        temp_path.unlink(missing_ok=True)

    # Fetch the document to return response matching schema
    result = await db.execute(select(Document).where(Document.id == uuid.UUID(document_id)))
    document = result.scalar_one_or_none()

    if not document:
         raise HTTPException(status_code=500, detail="Document uploaded but not found in DB")

    return document


@router.post("/search", response_model=RagSearchResponse)
async def search_rag(
    payload: RagSearchRequest,
    current_user: User = Depends(get_current_user),
    retriever: RAGRetriever = Depends(get_retriever),
) -> RagSearchResponse:
    results = await retriever.retrieve_context(
        user_id=current_user.id,
        query=payload.query,
        top_k=payload.top_k,
    )

    # Adapt retriever results to response model
    # Retriever returns: {text, filename, score, metadata}
    # Response expects: {content (alias text), score, metadata}
    return RagSearchResponse(
        results=[
            RagSearchResult(
                text=result.get("text", ""),
                score=result.get("score"),
                metadata=result.get("metadata", {}),
            )
            for result in results
        ]
    )
