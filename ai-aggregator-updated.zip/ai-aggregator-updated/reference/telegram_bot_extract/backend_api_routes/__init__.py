"""API routers and dependencies."""

from backend.api.agent_routes import router as agent_router
from backend.api.agent_routes import webhook_router as github_webhook_router
from backend.api.analytics_routes import router as analytics_router
from backend.api.chat_routes import router as chat_router
from backend.api.metrics_routes import router as metrics_router
from backend.api.rag_routes import router as rag_router
from backend.api.user_routes import router as user_router

__all__ = [
    "agent_router",
    "analytics_router",
    "chat_router",
    "metrics_router",
    "rag_router",
    "user_router",
    "github_webhook_router",
]
