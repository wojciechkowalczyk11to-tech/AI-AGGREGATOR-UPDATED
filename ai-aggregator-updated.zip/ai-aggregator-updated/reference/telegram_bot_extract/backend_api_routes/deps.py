from __future__ import annotations

import uuid
from typing import AsyncGenerator, Optional

from fastapi import Depends, Header, HTTPException, status, Request
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from jose import JWTError

from backend.database import get_db as _get_db
from backend.models import User
from backend.auth.jwt import decode_access_token

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token", auto_error=False)

async def get_db() -> AsyncGenerator[AsyncSession, None]:
    async for session in _get_db():
        yield session


async def get_current_user(
    request: Request,
    token: Optional[str] = Depends(oauth2_scheme),
    x_user_id: str | None = Header(None, alias="X-User-Id"), # Fallback/Legacy support if needed, or remove
    db: AsyncSession = Depends(get_db),
) -> User:
    user_id_str = None

    # Priority 1: JWT
    if token:
        user_id_str = decode_access_token(token)
        if not user_id_str:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Could not validate credentials",
                headers={"WWW-Authenticate": "Bearer"},
            )

    # Priority 2: X-User-Id (Only if no token, useful for dev or internal calls if secured otherwise)
    # For production, we should enforce JWT. But let's check if we want to support both.
    # The prompt emphasizes SECURITY. So X-User-Id spoofing is bad.
    # I will DISABLE X-User-Id for production security unless token is missing AND we are in dev?
    # No, strict security tests are running.
    # I will allow X-User-Id ONLY if token is not present, BUT logic in test_user_isolation
    # explicitly tests Authorization header.
    # I will switch to strict JWT.

    if not user_id_str:
        # Check X-User-Id just in case, but warn or fail?
        # deps.py existing code used X-User-Id.
        # I'll replace it.
        raise HTTPException(
             status_code=status.HTTP_401_UNAUTHORIZED,
             detail="Not authenticated",
             headers={"WWW-Authenticate": "Bearer"},
        )

    try:
        user_id = uuid.UUID(user_id_str)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid user credentials",
        ) from exc

    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if user is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")

    # Store user_id in request state for RateLimiter
    request.state.user_id = str(user.id)

    return user


async def get_current_superuser(
    current_user: User = Depends(get_current_user),
) -> User:
    if not current_user.is_superuser:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN, detail="Not enough privileges"
        )
    return current_user

# Alias for compatibility with admin routes
require_superuser = get_current_superuser
