import pytest
from unittest.mock import MagicMock, patch
from telegram_bot import handlers
from telegram_bot.handlers import _check_auth

def test_check_auth_denied():
    update = MagicMock()
    update.effective_user.id = 999

    mock_settings = MagicMock()
    mock_settings.allowed_telegram_user_ids = [123]

    with patch.object(handlers, "settings", mock_settings):
        assert _check_auth(update) is False

def test_check_auth_allowed():
    update = MagicMock()
    update.effective_user.id = 123

    mock_settings = MagicMock()
    mock_settings.allowed_telegram_user_ids = [123]

    with patch.object(handlers, "settings", mock_settings):
        assert _check_auth(update) is True

def test_check_auth_empty_list_denies_all():
    update = MagicMock()
    update.effective_user.id = 123

    mock_settings = MagicMock()
    mock_settings.allowed_telegram_user_ids = []

    with patch.object(handlers, "settings", mock_settings):
        assert _check_auth(update) is False
