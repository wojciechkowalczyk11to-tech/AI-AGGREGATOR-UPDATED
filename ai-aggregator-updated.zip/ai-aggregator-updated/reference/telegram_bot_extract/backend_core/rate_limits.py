"""
Rate limit configuration and tier definitions.
"""

from typing import TypedDict


class TierLimits(TypedDict):
    """Rate limits for a subscription tier."""
    tokens_per_day: int
    requests_per_hour: int
    rag_queries_per_day: int


TIER_LIMITS: dict[str, TierLimits] = {
    "basic": {
        "tokens_per_day": 10_000,
        "requests_per_hour": 50,
        "rag_queries_per_day": 50,
    },
    "premium": {
        "tokens_per_day": 100_000,
        "requests_per_hour": 500,
        "rag_queries_per_day": 500,
    },
    "premium_plus": {
        "tokens_per_day": 500_000,
        "requests_per_hour": 2_000,
        "rag_queries_per_day": 2_000,
    },
}

# Thresholds
WARNING_THRESHOLD = 0.80  # Show warning at 80% usage
BLOCK_THRESHOLD = 1.00     # Hard block at 100% usage

# Redis key templates
REDIS_KEY_REQUESTS = "ratelimit:requests:{user_id}:{period}"  # period = YYYYMMDDHH
REDIS_KEY_TOKENS = "ratelimit:tokens:{user_id}:{period}"      # period = YYYYMMDD
REDIS_KEY_RAG = "ratelimit:rag:{user_id}:{period}"            # period = YYYYMMDD


def get_tier_limits(tier: str) -> TierLimits:
    """Get limits for a tier, defaulting to basic if unknown."""
    return TIER_LIMITS.get(tier, TIER_LIMITS["basic"])
