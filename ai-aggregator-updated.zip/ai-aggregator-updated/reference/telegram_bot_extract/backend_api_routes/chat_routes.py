from __future__ import annotations

import logging
import uuid
from datetime import datetime, timezone
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.api.deps import get_current_user, get_db
from backend.api.dependencies import get_rate_limiter
from backend.config.settings import settings
from backend.middleware.rate_limiter import RateLimiter, RateLimitExceeded
from backend.models import Conversation, User
from backend.providers.factory import ProviderFactory
from backend.providers.types import ProviderRequest, ProviderResponse
from backend.rag.retriever import RAGRetriever
from backend.router.fallback import FallbackManager
from backend.router.router import ModelRouter
from backend.services.usage_service import UsageService
from backend.utils.rate_limiter import ChatLimiter

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/chat", tags=["chat"])


class ChatRequest(BaseModel):
    user_id: uuid.UUID
    prompt: str = Field(..., min_length=1)
    conversation_id: Optional[uuid.UUID] = None
    use_rag: bool = False
    stream: bool = False
    max_tokens: Optional[int] = Field(default=None, ge=1)
    temperature: Optional[float] = Field(default=None, ge=0)


class ChatResponse(BaseModel):
    conversation_id: uuid.UUID
    response: str
    model_name: str
    provider: str
    input_tokens: int
    output_tokens: int
    cost_usd: float
    rag_status: Optional[str] = None
    rag_message: Optional[str] = None


def get_model_router() -> ModelRouter:
    return ModelRouter()


def get_fallback_manager() -> FallbackManager:
    return FallbackManager(ProviderFactory.create)


def get_rag_retriever() -> RAGRetriever:
    return RAGRetriever()


def get_usage_service() -> UsageService:
    return UsageService()


def build_prompt(
    system_prompt: str,
    conversation_messages: List[dict],
    user_prompt: str,
) -> str:
    parts = [f"System: {system_prompt}"]
    for message in conversation_messages:
        role = message.get("role", "user")
        content = message.get("content", "")
        parts.append(f"{role.capitalize()}: {content}")
    parts.append(f"User: {user_prompt}")
    return "\n".join(parts).strip()


async def get_or_create_conversation(
    db: AsyncSession,
    user_id: uuid.UUID,
    conversation_id: Optional[uuid.UUID],
) -> Conversation:
    if conversation_id:
        result = await db.execute(
            select(Conversation).where(
                Conversation.id == conversation_id,
                Conversation.user_id == user_id,
            )
        )
        conversation = result.scalar_one_or_none()
        if conversation is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Conversation not found",
            )
        return conversation

    conversation = Conversation(user_id=user_id, messages=[])
    db.add(conversation)
    await db.commit()
    await db.refresh(conversation)
    return conversation


@router.get("/providers", response_model=List[str])
async def get_providers():
    """Return a list of available AI providers."""
    return ProviderFactory.get_available_providers()


@router.post("/", response_model=ChatResponse, dependencies=[Depends(ChatLimiter)])
async def chat(
    payload: ChatRequest,
    current_user: User = Depends(get_current_user),
    rate_limiter: RateLimiter = Depends(get_rate_limiter),
    db: AsyncSession = Depends(get_db),
    model_router: ModelRouter = Depends(get_model_router),
    fallback: FallbackManager = Depends(get_fallback_manager),
    rag_retriever: RAGRetriever = Depends(get_rag_retriever),
    usage_service: UsageService = Depends(get_usage_service),
):
    # 0. Check Cost Cap
    today_start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
    # Note: UsageService.get_system_stats_today might expect naive datetime depending on DB timezone,
    # but UTC is generally safe for comparison if DB is UTC.
    # We'll rely on it.
    stats = await usage_service.get_system_stats_today(db, today_start)
    if stats.get("total_cost_today", 0.0) >= settings.daily_cost_cap_usd:
        raise HTTPException(
            status_code=status.HTTP_402_PAYMENT_REQUIRED,
            detail={
                "error_code": "DAILY_CAP_REACHED",
                "message": "Daily cost limit reached.",
                "today_cost_usd": stats.get("total_cost_today", 0.0),
                "cap_usd": settings.daily_cost_cap_usd,
            },
        )

    # Check for provider commands and validate
    command, _ = model_router.parse_command(payload.prompt)
    if command:
        try:
            # Validation using the single source of truth (ProviderFactory)
            # ProviderFactory.create handles aliases like 'gpt' -> 'gpt-4'
            ProviderFactory.create(command)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Unknown provider. Use /help to see supported providers.",
            )

        # If valid, persist the preference
        plan_for_settings = model_router.get_provider(current_user.settings or {}, payload.prompt)

        new_settings = dict(current_user.settings or {})
        new_settings["preferred_model"] = plan_for_settings.primary_provider
        current_user.settings = new_settings
        db.add(current_user)
        await db.commit()


    # Estimate tokens (rough estimate before actual call)
    estimated_input_tokens = len(payload.prompt.split()) * 1.3  # ~1.3 tokens per word
    estimated_output_tokens = payload.max_tokens or 500  # Conservative estimate

    # Check token limit BEFORE calling LLM
    allowed, retry_after = await rate_limiter.check_token_limit(
        current_user,
        int(estimated_input_tokens),
        int(estimated_output_tokens),
    )
    if not allowed:
        raise RateLimitExceeded("tokens_per_day", retry_after)

    if payload.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User ID does not match authentication header",
        )

    conversation = await get_or_create_conversation(
        db, current_user.id, payload.conversation_id
    )

    messages = list(conversation.messages or [])

    rag_context: List[str] = []
    rag_status: Optional[str] = None
    rag_message: Optional[str] = None

    if payload.use_rag:
        if settings.rag_backend == "off":
            rag_status = "disabled"
            rag_message = "RAG is disabled. Set RAG_BACKEND=vertex_search or chroma."
        else:
            try:
                results = await rag_retriever.retrieve_context(
                    current_user.id, payload.prompt
                )
                rag_context = [r["text"] for r in results if r.get("text")]
                rag_status = "ok"
            except Exception as e:
                logger.error(f"RAG retrieval failed: {e}", exc_info=True)
                rag_status = "error"
                rag_message = str(e)
                # Fail open (continue chat without RAG) or fail?
                # Usually better to continue without context but warn.

    system_prompt = "You are a helpful assistant."
    if rag_context:
        context_block = "\n".join(rag_context)
        system_prompt = f"{system_prompt}\n\nContext:\n{context_block}"

    routing_plan = model_router.get_provider(current_user.settings or {}, payload.prompt)
    prompt = build_prompt(system_prompt, messages, routing_plan.prompt)

    request = ProviderRequest(
        prompt=prompt,
        max_tokens=payload.max_tokens,
        temperature=payload.temperature,
    )
    response: ProviderResponse = await fallback.execute(routing_plan.providers, request)

    # Use the original prompt for history (with command if present? or stripped?)
    # Usually we want to store what the user typed.
    messages.append({"role": "user", "content": payload.prompt})
    messages.append({"role": "assistant", "content": response.content})
    conversation.messages = messages
    await db.commit()
    await db.refresh(conversation)

    await usage_service.log_request(
        session=db,
        user_id=current_user.id,
        provider=response.provider,
        model=response.model_name,
        input_tokens=response.input_tokens,
        output_tokens=response.output_tokens,
        cost=response.cost_usd,
    )

    # Structured logging for cost/usage
    logger.info(
        f"Request processed: request_id={uuid.uuid4()} user_id={current_user.id} "
        f"provider={response.provider} model={response.model_name} "
        f"cost={response.cost_usd} rag_backend={settings.rag_backend}"
    )

    if payload.stream:
        async def stream_generator():
            yield response.content

        return StreamingResponse(stream_generator(), media_type="text/plain")

    return ChatResponse(
        conversation_id=conversation.id,
        response=response.content,
        model_name=response.model_name,
        provider=response.provider,
        input_tokens=response.input_tokens,
        output_tokens=response.output_tokens,
        cost_usd=response.cost_usd,
        rag_status=rag_status,
        rag_message=rag_message,
    )
