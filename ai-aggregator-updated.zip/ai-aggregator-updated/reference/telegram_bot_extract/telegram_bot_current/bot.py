from __future__ import annotations

import json
import logging
import sys

from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters

from telegram_bot.config import settings
from telegram_bot.handlers import (
    handle_message,
    help_command,
    settings_command,
    start_command,
)
from telegram_bot.services import BackendService

# Configure JSON logging
class JsonFormatter(logging.Formatter):
    def format(self, record):
        log_record = {
            "time": self.formatTime(record, self.datefmt),
            "name": record.name,
            "level": record.levelname,
            "message": record.getMessage(),
        }
        if record.exc_info:
            log_record["exception"] = self.formatException(record.exc_info)
        return json.dumps(log_record)

handler = logging.StreamHandler(sys.stdout)
handler.setFormatter(JsonFormatter())
logging.basicConfig(level=logging.INFO, handlers=[handler])


def main() -> None:
    # Validate settings before starting
    settings.validate()

    application = ApplicationBuilder().token(settings.telegram_bot_token).build()
    backend_service = BackendService(settings.backend_url)
    application.bot_data["backend_service"] = backend_service

    # Command handlers take precedence
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("settings", settings_command))
    application.add_handler(CommandHandler("help", help_command))

    # Handle all other text messages (including unregistered commands like /claude)
    # We remove ~filters.COMMAND so that slash commands fall through to here
    application.add_handler(
        MessageHandler(filters.TEXT, handle_message)
    )

    async def _on_shutdown(_: object) -> None:
        await backend_service.close()

    application.post_shutdown.append(_on_shutdown)

    if settings.mode == "webhook":
        logging.info(f"Starting webhook on {settings.webhook_listen}:{settings.webhook_port} path={settings.webhook_path}")
        application.run_webhook(
            listen=settings.webhook_listen,
            port=settings.webhook_port,
            url_path=settings.webhook_path,
            webhook_url=f"{settings.webhook_url.rstrip('/')}/{settings.webhook_path}",
            secret_token=settings.webhook_secret_token,
        )
    else:
        logging.info("Starting polling...")
        application.run_polling()


if __name__ == "__main__":
    main()
