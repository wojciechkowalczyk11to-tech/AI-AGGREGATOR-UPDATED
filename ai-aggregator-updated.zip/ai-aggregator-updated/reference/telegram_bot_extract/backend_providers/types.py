"""Typed requests/responses for provider interactions."""

from __future__ import annotations

from enum import Enum
from typing import Any, Optional, List

from pydantic import BaseModel, Field


class ProviderName(str, Enum):
    GEMINI_FLASH = "gemini-flash"
    CLAUDE_SONNET = "claude-sonnet"
    GPT_4 = "gpt-4"
    DEEPSEEK_CHAT = "deepseek-chat"
    GROQ_LLAMA = "groq-llama"
    MISTRAL_LARGE = "mistral-large"
    OPENROUTER = "openrouter"


class Message(BaseModel):
    role: str
    content: str


class ProviderRequest(BaseModel):
    prompt: Optional[str] = None
    messages: Optional[List[Message]] = None
    max_tokens: Optional[int] = None
    temperature: Optional[float] = None


class ProviderResponse(BaseModel):
    content: str
    input_tokens: int = Field(ge=0)
    output_tokens: int = Field(ge=0)
    cost_usd: float = Field(ge=0)
    model_name: str
    provider: str = "unknown"
    raw_response: Optional[Any] = None
