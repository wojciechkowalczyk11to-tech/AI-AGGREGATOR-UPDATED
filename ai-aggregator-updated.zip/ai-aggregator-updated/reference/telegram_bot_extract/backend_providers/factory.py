"""Factory for AI providers."""

from __future__ import annotations

import os
from typing import Union, Dict, List, Optional

from .base import AIProvider
from .types import ProviderName
from .gemini import GeminiProvider
from .claude import ClaudeProvider
from .openai import OpenAIProvider
from .deepseek import DeepSeekProvider
from .groq import GroqProvider
from .mistral import MistralProvider
from .openrouter import OpenRouterProvider


class ProviderFactory:
    """Factory to create providers based on name."""

    _providers: Dict[str, AIProvider] = {}

    @classmethod
    def get_provider(cls, name: str) -> AIProvider:
        """Get or create provider instance."""
        if name in cls._providers:
            return cls._providers[name]

        provider = cls.create(name)
        cls._providers[name] = provider
        return provider

    @staticmethod
    def create(provider_name: Union[str, ProviderName]) -> AIProvider:
        """Create a new provider instance."""
        # Normalize string to enum if possible, or just use string matching
        try:
            normalized = ProviderName(provider_name)
        except ValueError:
            normalized = None

        if normalized == ProviderName.GEMINI_FLASH or provider_name == "gemini":
            return GeminiProvider()
        elif normalized == ProviderName.CLAUDE_SONNET or provider_name == "claude":
            return ClaudeProvider()
        elif normalized == ProviderName.GPT_4 or provider_name == "openai" or provider_name == "gpt":
            return OpenAIProvider()
        elif normalized == ProviderName.DEEPSEEK_CHAT or provider_name == "deepseek":
            return DeepSeekProvider()
        elif normalized == ProviderName.GROQ_LLAMA or provider_name == "groq":
            return GroqProvider()
        elif normalized == ProviderName.MISTRAL_LARGE or provider_name == "mistral":
            return MistralProvider()
        elif normalized == ProviderName.OPENROUTER or provider_name == "openrouter":
            return OpenRouterProvider()

        # Aliases / Fallbacks
        if provider_name == "jules":
             # Jules uses Gemini for now
            return GeminiProvider()

        raise ValueError(f"Unsupported provider: {provider_name}")

    @staticmethod
    def get_available_providers() -> List[str]:
        """Get list of configured providers based on env vars."""
        providers = []
        # Gemini via Vertex (checks project or credentials)
        if os.getenv("GOOGLE_CLOUD_PROJECT") or os.getenv("GOOGLE_APPLICATION_CREDENTIALS") or os.getenv("GOOGLE_API_KEY"):
            providers.append("gemini")
        if os.getenv("CLAUDE_API_KEY"):
            providers.append("claude")
        if os.getenv("OPENAI_API_KEY"):
            providers.append("openai")
        if os.getenv("DEEPSEEK_API_KEY"):
            providers.append("deepseek")
        if os.getenv("GROQ_API_KEY"):
            providers.append("groq")
        if os.getenv("MISTRAL_API_KEY"):
            providers.append("mistral")
        if os.getenv("OPENROUTER_API_KEY"):
            providers.append("openrouter")
        return providers
