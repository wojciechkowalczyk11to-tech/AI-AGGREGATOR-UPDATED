import os
from typing import List

class Settings:
    def __init__(self):
        self.jwt_secret_key = os.getenv("JWT_SECRET_KEY")
        self.database_url = os.getenv("DATABASE_URL")
        self.allowed_origins = os.getenv("ALLOWED_ORIGINS")

        # Google Cloud & Vertex AI
        self.google_cloud_project = os.getenv("GOOGLE_CLOUD_PROJECT")
        self.google_cloud_location = os.getenv("GOOGLE_CLOUD_LOCATION", "global")
        self.vertex_gemini_model = os.getenv("VERTEX_GEMINI_MODEL", "gemini-3-flash-preview")
        self.vertex_gemini_thinking_level = os.getenv("VERTEX_GEMINI_THINKING_LEVEL", "HIGH")

        # RAG Configuration
        self.rag_backend = os.getenv("RAG_BACKEND", "off")
        self.vertex_search_serving_config = os.getenv("VERTEX_SEARCH_SERVING_CONFIG")

        # Cost Management
        self.daily_cost_cap_usd = float(os.getenv("DAILY_COST_CAP_USD", "10.0"))

        # Security
        self.owner_telegram_user_ids_str = os.getenv("OWNER_TELEGRAM_USER_IDS", "")

        self.validate()

    def validate(self):
        """Validate that all required environment variables are set."""
        missing_vars = []

        if not self.jwt_secret_key:
            missing_vars.append("JWT_SECRET_KEY")
        if not self.database_url:
            missing_vars.append("DATABASE_URL")
        if not self.allowed_origins:
            missing_vars.append("ALLOWED_ORIGINS")

        # Validate Vertex AI requirement if enabled (implied by usage, but project usually required)
        # If using Vertex, we need project.
        if self.rag_backend == "vertex_search" or "gemini" in self.vertex_gemini_model:
             # Technically we might not need project explicitly if using ADC, but good to have.
             pass

        if self.rag_backend not in ["off", "chroma", "vertex_search"]:
            raise ValueError(f"Invalid RAG_BACKEND: {self.rag_backend}. Must be one of: off, chroma, vertex_search")

        if self.rag_backend == "vertex_search":
             if not self.vertex_search_serving_config:
                 missing_vars.append("VERTEX_SEARCH_SERVING_CONFIG (required when RAG_BACKEND=vertex_search)")

        if self.vertex_gemini_thinking_level not in ["HIGH", "MEDIUM", "LOW", "NONE"]:
            raise ValueError(f"Invalid VERTEX_GEMINI_THINKING_LEVEL: {self.vertex_gemini_thinking_level}")

        if missing_vars:
            raise RuntimeError(
                f"Missing required environment variables: {', '.join(missing_vars)}. "
                "Please set these in your .env file or environment."
            )

    @property
    def allowed_origins_list(self):
        if self.allowed_origins:
            return [origin.strip() for origin in self.allowed_origins.split(",") if origin.strip()]
        return []

    @property
    def owner_telegram_user_ids(self) -> List[int]:
        if not self.owner_telegram_user_ids_str:
            return []
        try:
            return [int(uid.strip()) for uid in self.owner_telegram_user_ids_str.split(",") if uid.strip()]
        except ValueError:
            return []

settings = Settings()
