"""Prometheus metrics endpoint for JARVIS monitoring."""

from __future__ import annotations

from fastapi import APIRouter
from starlette.responses import Response

try:
    from prometheus_client import (
        Counter,
        Gauge,
        Histogram,
        generate_latest,
        CONTENT_TYPE_LATEST,
    )

    REQUESTS_TOTAL = Counter(
        "jarvis_requests_total",
        "Total requests",
        ["method", "endpoint", "status"],
    )

    REQUEST_LATENCY = Histogram(
        "jarvis_request_latency_seconds",
        "Request latency in seconds",
        ["endpoint"],
        buckets=(0.01, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0),
    )

    TOKENS_USED = Counter(
        "jarvis_tokens_total",
        "Total tokens used",
        ["provider", "model"],
    )

    COST_USD = Counter(
        "jarvis_cost_usd_total",
        "Total cost in USD",
        ["provider"],
    )

    ACTIVE_TASKS = Gauge(
        "jarvis_active_tasks",
        "Currently running agent tasks",
    )

    REACT_STEPS = Counter(
        "jarvis_react_steps_total",
        "Total ReAct engine steps executed",
        ["action_type"],
    )

    PROMETHEUS_AVAILABLE = True

except ImportError:
    PROMETHEUS_AVAILABLE = False
    REQUESTS_TOTAL = None
    REQUEST_LATENCY = None
    TOKENS_USED = None
    COST_USD = None
    ACTIVE_TASKS = None
    REACT_STEPS = None

router = APIRouter(tags=["monitoring"])


@router.get("/metrics")
async def metrics() -> Response:
    """Prometheus metrics endpoint."""
    if not PROMETHEUS_AVAILABLE:
        return Response(
            content="# prometheus_client not installed\n",
            media_type="text/plain",
        )

    return Response(
        content=generate_latest(),
        media_type=CONTENT_TYPE_LATEST,
    )
