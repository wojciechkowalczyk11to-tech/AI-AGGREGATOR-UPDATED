"""
Admin API routes for system monitoring and user management.
Requires superuser privileges (is_superuser=True).
"""

from datetime import datetime, timedelta
from decimal import Decimal
from typing import List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import func, select, and_
from sqlalchemy.ext.asyncio import AsyncSession

from backend.api.deps import get_db, require_superuser
from backend.models.user import User
from backend.models.usage import UsageLog


router = APIRouter(prefix="/admin", tags=["admin"])


# ============================================================================
# RESPONSE MODELS
# ============================================================================

class UserStatsResponse(BaseModel):
    """Statistics for a single user."""
    user_id: UUID
    telegram_id: int
    subscription_tier: str
    created_at: datetime
    total_requests: int
    total_cost_usd: Decimal
    total_tokens: int  # input + output
    last_activity: Optional[datetime]
    most_used_provider: Optional[str]


class CostBreakdownItem(BaseModel):
    """Cost breakdown for a single provider."""
    provider: str
    model: str
    total_cost_usd: Decimal
    request_count: int
    total_tokens: int
    percentage: float  # % of total system cost


class CostBreakdownResponse(BaseModel):
    """Aggregated cost breakdown across all providers."""
    total_cost_usd: Decimal
    period_start: datetime
    period_end: datetime
    breakdown: List[CostBreakdownItem]


class UserUsageDetail(BaseModel):
    """Detailed usage record for a user."""
    timestamp: datetime
    provider: str
    model: str
    request_type: str
    input_tokens: int
    output_tokens: int
    cost_usd: Decimal


class UserUsageHistoryResponse(BaseModel):
    """Paginated usage history for a user."""
    user_id: UUID
    total_records: int
    page: int
    page_size: int
    records: List[UserUsageDetail]


class TierUpgradeRequest(BaseModel):
    """Request body for manual tier upgrade."""
    new_tier: str = Field(..., pattern="^(basic|premium|premium_plus)$")
    reason: Optional[str] = None


class SystemStatsResponse(BaseModel):
    """System-wide statistics overview."""
    total_users: int
    active_users_24h: int  # users with requests in last 24h
    total_requests_24h: int
    total_cost_24h: Decimal
    total_cost_all_time: Decimal
    avg_cost_per_request: Decimal
    most_popular_provider: str
    tier_distribution: dict[str, int]  # {"basic": 42, "premium": 8, ...}


# ============================================================================
# ENDPOINTS
# ============================================================================

@router.get("/users", response_model=List[UserStatsResponse])
async def list_all_users(
    db: AsyncSession = Depends(get_db),
    _admin: User = Depends(require_superuser),
    limit: int = Query(100, ge=1, le=500),
    offset: int = Query(0, ge=0),
    tier_filter: Optional[str] = Query(None, pattern="^(basic|premium|premium_plus)$"),
) -> List[UserStatsResponse]:
    """
    List all users with aggregated usage statistics.
    Optimized to avoid N+1 queries.

    Query params:
    - limit: Max results (1-500, default 100)
    - offset: Pagination offset
    - tier_filter: Filter by subscription tier
    """
    # 1. Get Users (Paginated)
    query = select(User)
    if tier_filter:
        query = query.where(User.subscription_tier == tier_filter)
    query = query.limit(limit).offset(offset).order_by(User.created_at.desc())

    result = await db.execute(query)
    users = result.scalars().all()

    if not users:
        return []

    user_ids = [u.id for u in users]

    # 2. Get Aggregated Stats for these users
    stats_stmt = (
        select(
            UsageLog.user_id,
            func.count(UsageLog.id).label("total_requests"),
            func.sum(UsageLog.cost_usd).label("total_cost"),
            func.sum(UsageLog.input_tokens + UsageLog.output_tokens).label("total_tokens"),
            func.max(UsageLog.timestamp).label("last_activity"),
        )
        .where(UsageLog.user_id.in_(user_ids))
        .group_by(UsageLog.user_id)
    )

    stats_result = await db.execute(stats_stmt)
    stats_map = {row.user_id: row for row in stats_result.all()}

    # 3. Get Most Used Provider
    # Calculate counts per provider per user
    # We do this in Python to avoid complex window functions/compatibility issues,
    # fetching only necessary data (provider counts for these users)
    provider_stmt = (
        select(
            UsageLog.user_id,
            UsageLog.provider,
            func.count(UsageLog.id).label("cnt")
        )
        .where(UsageLog.user_id.in_(user_ids))
        .group_by(UsageLog.user_id, UsageLog.provider)
    )

    provider_result = await db.execute(provider_stmt)
    provider_rows = provider_result.all()

    # Determine top provider in Python
    user_providers = {} # user_id -> list of (provider, count)
    for row in provider_rows:
        if row.user_id not in user_providers:
            user_providers[row.user_id] = []
        user_providers[row.user_id].append((row.provider, row.cnt))

    most_used_provider_map = {}
    for uid, providers in user_providers.items():
        # Sort by count desc
        providers.sort(key=lambda x: x[1], reverse=True)
        if providers:
            most_used_provider_map[uid] = providers[0][0]

    # Assemble Response
    response = []
    for user in users:
        stats = stats_map.get(user.id)
        most_used_provider = most_used_provider_map.get(user.id)

        total_requests = stats.total_requests if stats else 0
        total_cost = stats.total_cost if stats and stats.total_cost is not None else 0.0
        total_tokens = stats.total_tokens if stats and stats.total_tokens is not None else 0
        last_activity = stats.last_activity if stats else None

        response.append(UserStatsResponse(
            user_id=user.id,
            telegram_id=user.telegram_chat_id,
            subscription_tier=user.subscription_tier,
            created_at=user.created_at,
            total_requests=total_requests,
            total_cost_usd=Decimal(str(total_cost)),
            total_tokens=total_tokens,
            last_activity=last_activity,
            most_used_provider=most_used_provider,
        ))

    return response


@router.get("/costs/breakdown", response_model=CostBreakdownResponse)
async def get_cost_breakdown(
    db: AsyncSession = Depends(get_db),
    _admin: User = Depends(require_superuser),
    days: int = Query(7, ge=1, le=365, description="Number of days to analyze"),
) -> CostBreakdownResponse:
    """
    Get cost breakdown by provider/model for specified period.
    Returns data suitable for pie charts and cost dashboards.
    """
    period_start = datetime.utcnow() - timedelta(days=days)
    period_end = datetime.utcnow()

    # Aggregate by provider and model
    query = select(
        UsageLog.provider,
        UsageLog.model,
        func.sum(UsageLog.cost_usd).label("total_cost"),
        func.count(UsageLog.id).label("request_count"),
        func.sum(UsageLog.input_tokens + UsageLog.output_tokens).label("total_tokens"),
    ).where(
        UsageLog.timestamp >= period_start
    ).group_by(UsageLog.provider, UsageLog.model).order_by(func.sum(UsageLog.cost_usd).desc())

    result = await db.execute(query)
    rows = result.all()

    # Calculate total for percentages
    total_cost = sum(Decimal(str(row.total_cost)) for row in rows)

    breakdown = [
        CostBreakdownItem(
            provider=row.provider,
            model=row.model,
            total_cost_usd=Decimal(str(row.total_cost)),
            request_count=row.request_count,
            total_tokens=row.total_tokens or 0,
            percentage=float((Decimal(str(row.total_cost)) / total_cost * 100) if total_cost > 0 else 0),
        )
        for row in rows
    ]

    return CostBreakdownResponse(
        total_cost_usd=total_cost,
        period_start=period_start,
        period_end=period_end,
        breakdown=breakdown,
    )


@router.get("/users/{user_id}/usage", response_model=UserUsageHistoryResponse)
async def get_user_usage_history(
    user_id: UUID,
    db: AsyncSession = Depends(get_db),
    _admin: User = Depends(require_superuser),
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
    provider_filter: Optional[str] = None,
) -> UserUsageHistoryResponse:
    """
    Get detailed usage history for a specific user.

    Query params:
    - page: Page number (1-based)
    - page_size: Records per page (1-200)
    - provider_filter: Filter by provider name
    """
    # Verify user exists
    user_query = select(User).where(User.id == user_id)
    user_result = await db.execute(user_query)
    user = user_result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    # Build query
    query = select(UsageLog).where(UsageLog.user_id == user_id)
    if provider_filter:
        query = query.where(UsageLog.provider == provider_filter)

    # Count total
    count_query = select(func.count()).select_from(query.subquery())
    total_result = await db.execute(count_query)
    total_records = total_result.scalar()

    # Paginate
    offset = (page - 1) * page_size
    query = query.order_by(UsageLog.timestamp.desc()).limit(page_size).offset(offset)

    result = await db.execute(query)
    logs = result.scalars().all()

    records = [
        UserUsageDetail(
            timestamp=log.timestamp,
            provider=log.provider,
            model=log.model,
            request_type=log.request_type,
            input_tokens=log.input_tokens,
            output_tokens=log.output_tokens,
            cost_usd=Decimal(str(log.cost_usd)),
        )
        for log in logs
    ]

    return UserUsageHistoryResponse(
        user_id=user_id,
        total_records=total_records,
        page=page,
        page_size=page_size,
        records=records,
    )


@router.post("/users/{user_id}/upgrade", status_code=200)
async def upgrade_user_tier(
    user_id: UUID,
    request: TierUpgradeRequest,
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(require_superuser),
) -> dict:
    """
    Manually upgrade/downgrade a user's subscription tier.
    Requires superuser privileges.
    """
    # Get user
    query = select(User).where(User.id == user_id)
    result = await db.execute(query)
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    old_tier = user.subscription_tier
    user.subscription_tier = request.new_tier
    await db.commit()

    # Log the action (could extend UsageLog or create AuditLog table)
    # For now, just return success

    return {
        "success": True,
        "user_id": str(user_id),
        "old_tier": old_tier,
        "new_tier": request.new_tier,
        "upgraded_by": admin.telegram_chat_id,
        "reason": request.reason,
    }


@router.get("/stats/overview", response_model=SystemStatsResponse)
async def get_system_overview(
    db: AsyncSession = Depends(get_db),
    _admin: User = Depends(require_superuser),
) -> SystemStatsResponse:
    """
    Get system-wide statistics overview.
    Includes active users, total costs, and tier distribution.
    """
    # Total users
    total_users_query = select(func.count(User.id))
    total_users_result = await db.execute(total_users_query)
    total_users = total_users_result.scalar()

    # Active users in last 24h
    day_ago = datetime.utcnow() - timedelta(hours=24)
    active_users_query = select(func.count(func.distinct(UsageLog.user_id))).where(
        UsageLog.timestamp >= day_ago
    )
    active_users_result = await db.execute(active_users_query)
    active_users_24h = active_users_result.scalar()

    # Requests and costs in last 24h
    stats_24h_query = select(
        func.count(UsageLog.id).label("total_requests"),
        func.sum(UsageLog.cost_usd).label("total_cost"),
    ).where(UsageLog.timestamp >= day_ago)
    stats_24h_result = await db.execute(stats_24h_query)
    stats_24h = stats_24h_result.one()

    # All-time cost
    total_cost_query = select(func.sum(UsageLog.cost_usd))
    total_cost_result = await db.execute(total_cost_query)
    total_cost_all_time = total_cost_result.scalar() or Decimal("0.0")

    # Average cost per request
    total_cost_24h_decimal = Decimal(str(stats_24h.total_cost)) if stats_24h.total_cost is not None else Decimal("0.0")
    total_requests_24h_int = stats_24h.total_requests or 0
    avg_cost = (total_cost_24h_decimal / total_requests_24h_int) if total_requests_24h_int > 0 else Decimal("0.0")

    # Most popular provider (last 24h)
    provider_query = select(
        UsageLog.provider,
        func.count(UsageLog.id).label("count")
    ).where(UsageLog.timestamp >= day_ago).group_by(UsageLog.provider).order_by(func.count(UsageLog.id).desc()).limit(1)
    provider_result = await db.execute(provider_query)
    provider_row = provider_result.first()
    most_popular_provider = provider_row[0] if provider_row else "none"

    # Tier distribution
    tier_query = select(
        User.subscription_tier,
        func.count(User.id).label("count")
    ).group_by(User.subscription_tier)
    tier_result = await db.execute(tier_query)
    tier_rows = tier_result.all()
    tier_distribution = {row.subscription_tier: row.count for row in tier_rows}

    return SystemStatsResponse(
        total_users=total_users or 0,
        active_users_24h=active_users_24h or 0,
        total_requests_24h=total_requests_24h_int,
        total_cost_24h=total_cost_24h_decimal,
        total_cost_all_time=Decimal(str(total_cost_all_time)),
        avg_cost_per_request=avg_cost,
        most_popular_provider=most_popular_provider,
        tier_distribution=tier_distribution,
    )
