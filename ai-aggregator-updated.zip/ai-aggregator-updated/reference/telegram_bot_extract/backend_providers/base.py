"""Base abstractions for AI providers."""

from __future__ import annotations

from abc import ABC, abstractmethod

from .types import ProviderRequest, ProviderResponse


class AIProvider(ABC):
    """Defines the interface for AI providers."""

    @abstractmethod
    async def generate(self, request: ProviderRequest) -> ProviderResponse:
        """Generate a response from the model."""

    @abstractmethod
    async def count_tokens(self, text: str) -> int:
        """Count tokens for the given text."""

    @abstractmethod
    def calculate_cost(self, input_tokens: int, output_tokens: int) -> float:
        """Calculate the USD cost for the request."""

    @abstractmethod
    def get_model_name(self) -> str:
        """Return the provider model name."""
