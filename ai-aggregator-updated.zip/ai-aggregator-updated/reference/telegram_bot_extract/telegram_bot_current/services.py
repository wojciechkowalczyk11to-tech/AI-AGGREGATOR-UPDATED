from __future__ import annotations

from typing import Any, List

import httpx


class BackendServiceError(Exception):
    """Raised when the backend service returns an error (5xx or connection)."""


class AuthenticationError(BackendServiceError):
    """Raised when backend returns 401."""


class ClientError(BackendServiceError):
    """Raised when backend returns 400-499 (except 401)."""


class BackendService:
    def __init__(self, base_url: str, timeout: float = 30.0) -> None:
        self._client = httpx.AsyncClient(base_url=base_url, timeout=timeout)

    async def register_user(self, telegram_chat_id: int, settings: dict | None = None) -> dict:
        """Register user and return full user object with access_token."""
        payload = {"telegram_chat_id": telegram_chat_id, "settings": settings or {}}
        return await self._request("POST", "/api/users/register", json=payload)

    async def update_settings(self, user_id: str, access_token: str, settings: dict) -> dict:
        headers = {"Authorization": f"Bearer {access_token}"}
        payload = {"settings": settings}
        return await self._request("PUT", f"/api/users/{user_id}/settings", json=payload, headers=headers)

    async def get_supported_providers(self) -> List[str]:
        return await self._request("GET", "/api/chat/providers")

    async def send_message(
        self,
        user_id: str,
        access_token: str,
        prompt: str,
        conversation_id: str | None = None,
    ) -> dict:
        headers = {
            "Authorization": f"Bearer {access_token}",
        }
        payload = {
            "user_id": user_id,
            "prompt": prompt,
        }
        if conversation_id:
            payload["conversation_id"] = conversation_id

        return await self._request("POST", "/api/chat/", json=payload, headers=headers)

    async def close(self) -> None:
        await self._client.aclose()

    async def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        try:
            response = await self._client.request(method, path, **kwargs)
            if response.status_code == 401:
                raise AuthenticationError("Authentication failed")
            if 400 <= response.status_code < 500:
                # We want to propagate the error message for 400s (like unknown provider)
                try:
                    detail = response.json().get("detail", "Client error")
                except Exception:
                    detail = response.text
                raise ClientError(f"{detail}")

            response.raise_for_status()
            return response.json()
        except httpx.TimeoutException as exc:
             raise BackendServiceError("Request timed out") from exc
        except (httpx.RequestError, httpx.HTTPStatusError) as exc:
             # If it was already handled above as Auth/Client error, it raised.
             # If it wasn't (e.g. 500), we catch here.
             raise BackendServiceError(f"Backend request failed: {exc}") from exc
