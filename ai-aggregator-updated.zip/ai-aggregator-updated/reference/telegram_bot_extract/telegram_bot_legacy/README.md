# Legacy Telegram Bot

Legacy copy kept for history. Production bot lives in `ai-aggregator/telegram_bot`.
