import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from telegram_bot import handlers, services

@pytest.fixture
def mock_settings():
    # Patch the 'settings' object in the handlers module directly
    # This ensures that even if it's already imported, we replace the reference
    # or attribute lookup.
    with patch("telegram_bot.handlers.settings") as mock:
        mock.allowed_telegram_user_ids = [123]
        yield mock

@pytest.mark.asyncio
async def test_handle_message_success(mock_settings):
    # Setup
    update = MagicMock()
    update.message.text = "Hello"
    update.effective_user.id = 123
    update.effective_chat.id = 456
    update.message.reply_text = AsyncMock() # Must be awaitable

    context = MagicMock()
    context.user_data = {"backend_user_id": "uid", "access_token": "token", "conversation_id": "cid"}

    mock_backend = AsyncMock()
    mock_backend.send_message.return_value = {
        "response": "Hi there",
        "model_name": "gpt-4",
        "provider": "openai",
        "conversation_id": "cid2"
    }
    context.bot_data = {"backend_service": mock_backend}
    context.bot = AsyncMock()

    # Execute
    await handlers.handle_message(update, context)

    # Verify
    mock_backend.send_message.assert_called_with(
        user_id="uid",
        access_token="token",
        prompt="Hello",
        conversation_id="cid"
    )
    # Check formatting
    update.message.reply_text.assert_called_with("gpt-4: Hi there")
    assert context.user_data["conversation_id"] == "cid2"

@pytest.mark.asyncio
async def test_handle_message_command_only(mock_settings):
    # Setup
    update = MagicMock()
    update.message.text = "/claude"
    update.effective_user.id = 123
    update.effective_chat.id = 456
    update.message.reply_text = AsyncMock()

    context = MagicMock()
    context.user_data = {"backend_user_id": "uid", "access_token": "token"}

    mock_backend = AsyncMock()
    mock_backend.update_settings.return_value = {} # Success
    context.bot_data = {"backend_service": mock_backend}
    context.bot = AsyncMock()

    # Execute
    await handlers.handle_message(update, context)

    # Verify
    mock_backend.update_settings.assert_called_with(
        user_id="uid",
        access_token="token",
        settings={"preferred_model": "claude"}
    )
    # Check reply
    update.message.reply_text.assert_called_with("Switched to claude. Send message...")
    # Verify send_message was NOT called
    mock_backend.send_message.assert_not_called()

@pytest.mark.asyncio
async def test_handle_message_unknown_provider(mock_settings):
    # Setup
    update = MagicMock()
    update.message.text = "/unknown hello" # With prompt, so it hits chat endpoint
    update.effective_user.id = 123
    update.effective_chat.id = 456
    update.message.reply_text = AsyncMock()

    context = MagicMock()
    context.user_data = {"backend_user_id": "uid", "access_token": "token"}
    context.bot = AsyncMock()

    mock_backend = AsyncMock()
    # Simulate 400 ClientError
    mock_backend.send_message.side_effect = services.ClientError("Unknown provider")
    context.bot_data = {"backend_service": mock_backend}

    await handlers.handle_message(update, context)

    update.message.reply_text.assert_called_with("Unknown provider")

@pytest.mark.asyncio
async def test_handle_message_auth_refresh(mock_settings):
    # Setup
    update = MagicMock()
    update.message.text = "Hello"
    update.effective_user.id = 123
    update.effective_chat.id = 456
    update.message.reply_text = AsyncMock()

    context = MagicMock()
    context.user_data = {"backend_user_id": "uid", "access_token": "old_token"}
    context.bot = AsyncMock()

    mock_backend = AsyncMock()
    # First call fails with 401, Second call succeeds
    mock_backend.send_message.side_effect = [
        services.AuthenticationError("Auth failed"),
        {"response": "Retry success", "model_name": "m", "provider": "p"}
    ]
    # Register returns new token
    mock_backend.register_user.return_value = {"id": "uid", "access_token": "new_token"}

    context.bot_data = {"backend_service": mock_backend}

    await handlers.handle_message(update, context)

    # Verify register called
    mock_backend.register_user.assert_called_with(123)
    # Verify token updated
    assert context.user_data["access_token"] == "new_token"
    # Verify send_message called twice
    assert mock_backend.send_message.call_count == 2
    # Verify second call arguments
    call_args = mock_backend.send_message.call_args_list
    assert call_args[0].kwargs["access_token"] == "old_token"
    assert call_args[1].kwargs["access_token"] == "new_token"

    update.message.reply_text.assert_called_with("m: Retry success")
