"""Analytics routes for usage stats and provider comparison."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, Query
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.api.deps import get_current_user, get_db
from backend.models.usage import UsageLog
from backend.models.user import User

router = APIRouter(prefix="/analytics", tags=["analytics"])


@router.get("/usage")
async def get_usage_stats(
    days: int = Query(30, ge=1, le=365),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Get user's token usage and costs over the last N days."""
    start_date = datetime.now(timezone.utc) - timedelta(days=days)

    # Query aggregated by day and provider
    query = (
        select(
            func.date(UsageLog.timestamp).label("date"),
            UsageLog.provider,
            func.sum(UsageLog.total_tokens).label("tokens"),
            func.sum(UsageLog.cost_usd).label("cost"),
            func.count(UsageLog.id).label("request_count"),
        )
        .where(
            UsageLog.user_id == current_user.id,
            UsageLog.timestamp >= start_date,
        )
        .group_by(
            func.date(UsageLog.timestamp),
            UsageLog.provider,
        )
        .order_by(func.date(UsageLog.timestamp))
    )

    result = await db.execute(query)
    rows = result.all()

    data = []
    total_tokens = 0
    total_cost = 0.0

    for row in rows:
        tokens = row.tokens or 0
        cost = row.cost or 0.0
        total_tokens += tokens
        total_cost += cost

        data.append(
            {
                "date": str(row.date),
                "provider": row.provider,
                "tokens": tokens,
                "cost_usd": round(cost, 4),
                "request_count": row.request_count or 0,
            }
        )

    return {
        "period_days": days,
        "data": data,
        "totals": {
            "tokens": total_tokens,
            "cost_usd": round(total_cost, 2),
        },
    }


@router.get("/usage/compare")
async def compare_providers(
    input_tokens: int = Query(1000, ge=1),
    output_tokens: int = Query(500, ge=1),
) -> dict:
    """Compare costs across all providers for given token counts."""
    from backend.agents.monitoring.cost_calculator import CostCalculator

    calculator = CostCalculator()
    comparisons = calculator.compare_providers(input_tokens, output_tokens)

    return {
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "providers": [
            {
                "provider": c.provider,
                "model": c.model,
                "cost_usd": float(c.total_cost_usd),
                "input_cost": float(c.input_cost_usd),
                "output_cost": float(c.output_cost_usd),
            }
            for c in comparisons
        ],
    }
