from __future__ import annotations

import uuid
from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.api.deps import get_current_user, get_db
from backend.auth.jwt import create_access_token
from backend.config.settings import settings
from backend.models import User

router = APIRouter(tags=["users"])


class UserRegisterRequest(BaseModel):
    telegram_chat_id: int = Field(..., ge=1)
    settings: dict = Field(default_factory=dict)


class UserSettingsUpdate(BaseModel):
    settings: dict


class UserResponse(BaseModel):
    id: uuid.UUID
    telegram_chat_id: int
    settings: dict
    created_at: datetime
    access_token: Optional[str] = None
    token_type: Optional[str] = None


@router.post("/users/register", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
async def register_user(
    payload: UserRegisterRequest,
    db: AsyncSession = Depends(get_db),
) -> UserResponse:
    # Security: Owner-only check
    if settings.owner_telegram_user_ids and payload.telegram_chat_id not in settings.owner_telegram_user_ids:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"error_code": "OWNER_ONLY", "message": "Access denied for this user."},
        )

    existing = await db.execute(
        select(User).where(User.telegram_chat_id == payload.telegram_chat_id)
    )
    user = existing.scalar_one_or_none()

    if user is None:
        user = User(telegram_chat_id=payload.telegram_chat_id, settings=payload.settings)
        db.add(user)
        await db.commit()
        await db.refresh(user)

    # Generate token for both new and existing users
    access_token = create_access_token(user_id=str(user.id))

    return UserResponse(
        id=user.id,
        telegram_chat_id=user.telegram_chat_id,
        settings=user.settings,
        created_at=user.created_at,
        access_token=access_token,
        token_type="bearer",
    )


@router.put("/users/{user_id}/settings", response_model=UserResponse)
async def update_user_settings(
    user_id: uuid.UUID,
    payload: UserSettingsUpdate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> UserResponse:
    if current_user.id != user_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User ID does not match authentication header",
        )

    # We use current_user directly since it's already fetched
    current_user.settings = payload.settings
    db.add(current_user)
    await db.commit()
    await db.refresh(current_user)

    return UserResponse(
        id=current_user.id,
        telegram_chat_id=current_user.telegram_chat_id,
        settings=current_user.settings,
        created_at=current_user.created_at,
        # We don't necessarily need to return a new token on settings update, but the schema allows None
        access_token=None,
        token_type=None
    )
